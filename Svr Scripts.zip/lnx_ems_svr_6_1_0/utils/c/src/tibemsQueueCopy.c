/*-#-+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*
*                                                                              *
*       File Name       : tibemsQueueCopy.c                                    *
*                                                                              *
*       Description     : This tool helps copy messages of a queue             *
*                                                                              *
*       EMS Version     : 4.0.0                                                *
*       Supported         4.1.0                                                *
*                         4.2.1 (Not Released)                                 *
*                         4.3.0                                                *
*                         4.4.0 (Not Released)                                 *
*                         4.4.1                                                *
*                         4.4.3                                                *
*                         5.1.4 (Not Released)                                 *
*                         6.0.0 (Not Released)                                 *
*                         6.0.1                                                *
*                         6.1.0                                                *
*                                                                              *
*       Maintenance Log :                                                      *
*                                                                              *
*       Date        Version     Programmer      Description                    *
*       ----------- -------     --------------  ----------------------------   *
*       2008 Jun    1.0         Roshan D'Mello  Creation of original file      *
*                                                                              *
*---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*/


/*
 * Usage:  tibemsQueueCopy [options]
 *
 *    where options are:
 *
 *      -server     Server URL.
 *                  If not specified this sample assumes a
 *                  serverUrl of "tcp://localhost:7222"
 *
 *      -user       User name. Default is null.
 *      -password   User password. Default is null.
 *      -queue      Queue name. Default is "queue.sample.browser"
 *      -qcopy      Queue to which messages are copied. Default is "queue.sample.copy"
 *      -noofmsg    Number of messages to browse; '0' for all messages [default]
 *      -dispmsg    Display Message. 0 - NO [default] and 1 - YES
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include <tibems/tibems.h>

/*-----------------------------------------------------------------------
 * Parameters
 *----------------------------------------------------------------------*/

char*   serverUrl    = NULL;
char*   userName     = NULL;
char*   password     = NULL;
char*   pk_password  = NULL;
char*   queueName    = "queue.sample.browser";
char*   qcopyName    = "queue.sample.copy";
int	noofmsg	     = 0;
int	dispmsg	     = 0;


/*-----------------------------------------------------------------------
 * Variables
 *----------------------------------------------------------------------*/
tibemsTopicConnectionFactory  factory          = NULL;
tibemsQueueConnection         queueConnection  = NULL;
tibemsQueueSession            queueSession     = NULL;
tibemsQueueBrowser            queueBrowser     = NULL;
tibemsQueueSender             qcopySender      = NULL;
tibemsQueue                   queue            = NULL;           
tibemsQueue                   qcopy            = NULL;           

/*-----------------------------------------------------------------------
 * usage
 *----------------------------------------------------------------------*/
void usage() 
{
    printf("\nUsage: tibemsQueueCopy [options]\n");
    printf("\n");
    printf("   where options are:\n");
    printf("\n");
    printf(" -server   <server URL>  - EMS server URL, default is local server\n");
    printf(" -user     <user name>   - user name, default is null\n");
    printf(" -password <password>    - password, default is null\n");
    printf(" -queue    <queue-name>  - queue name, default is \"queue.sample.browser\"\n");
    printf(" -qcopy    <qcopy-name>  - Queue to which messages are copied, default is \"queue.sample.copy\"\n");
    printf(" -noofmsg  <no. of msg>  - number of messages to browse; '0' for all messages [default]\n");
    printf(" -dispmsg  <display msg> - Display message payload; 0 - NO [default] and 1 - YES\n"); 
    exit(0);
}

/*-----------------------------------------------------------------------
 * parseArgs
 *----------------------------------------------------------------------*/
void parseArgs(int argc, char** argv) 
{
    int i=1;
    
    while(i < argc)
    {
        if (!argv[i]) 
        {
            i += 1;
        }
        else
        if (strcmp(argv[i],"-help")==0) 
        {
            usage();
        }
        else
        if (strcmp(argv[i],"-server")==0) 
        {
            if ((i+1) >= argc) usage();
            serverUrl = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-queue")==0) 
        {
            if ((i+1) >= argc) usage();
            queueName = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-qcopy")==0) 
        {
            if ((i+1) >= argc) usage();
            qcopyName = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-user")==0) 
        {
            if ((i+1) >= argc) usage();
            userName = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-password")==0) 
        {
            if ((i+1) >= argc) usage();
            password = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-noofmsg")==0)
        {
            if ((i+1) >= argc) usage();
            noofmsg = atoi(argv[i+1]);
            i += 2;
        }
        else
        if (strcmp(argv[i],"-dispmsg")==0)
        {
            if ((i+1) >= argc) usage();
            dispmsg = atoi(argv[i+1]);
            i += 2;
        }
        else 
        {
            printf("Unrecognized parameter: %s\n",argv[i]);
            usage();
        }
    }
}

/*---------------------------------------------------------------------
 * fail
 *---------------------------------------------------------------------*/
void fail(
    const char* message, 
    tibems_status s)
{
    const char* msg = tibemsStatus_GetText(s);
    printf("ERROR: %s\n",message);
    printf("\tSTATUS: %d %s\n",s,msg?msg:"(Undefined Error)");
    exit(1);
}

/*---------------------------------------------------------------------
 * onException
 *---------------------------------------------------------------------*/
void onException(
    tibemsConnection    conn,
    tibems_status       reason,
    void*               closure)
{
    /* print the connection exception status */

    if (reason == TIBEMS_SERVER_NOT_CONNECTED)
    {
        printf("CONNECTION EXCEPTION: Server Disconnected\n");
    }
}

/*-----------------------------------------------------------------------
 * closeAll
 *----------------------------------------------------------------------*/
void closeAll() 
{
    tibems_status status   = TIBEMS_OK;

    /* close the browser */
    status = tibemsQueueBrowser_Close(queueBrowser);
    if (status != TIBEMS_OK)
    {
        fail("Error closing tibemsQueueBrowser", status);
    }
    
    /* destroy the queue */
    status = tibemsQueue_Destroy(queue);
    if (status != TIBEMS_OK)
    {
        fail("Error destroying tibemsQueue", status);
    }

    /* destroy the queue */
    status = tibemsQueue_Destroy(qcopy);
    if (status != TIBEMS_OK)
    {
        fail("Error destroying tibemsQueue", status);
    }

    /* close the connection */
    status = tibemsConnection_Close(queueConnection);
    if (status != TIBEMS_OK)
    {
        fail("Error closing tibemsQueueConnection", status);
    }
}

/*-----------------------------------------------------------------------
 * run
 *----------------------------------------------------------------------*/
void run() 
{
    tibems_status status   = TIBEMS_OK;
    tibemsMsg     msg      = NULL;
    tibems_int	  msgsize  = 0;
    int           browsec  = 0;
    int           i        = 0;

    if (!queueName) {
        printf("***Error: must specify queue name\n");
        usage();
    }
    
    printf("Browsing queue: '%s'\n",queueName);
    
    factory  = tibemsConnectionFactory_Create();
    if (!factory)
    {
        fail("Error creating tibemsConnectionFactory", status);
    }

    status = tibemsConnectionFactory_SetType(factory, TIBEMS_QUEUE_CONNECTION_FACTORY);
    if (status != TIBEMS_OK) 
    {
        fail("Error setting connection factory type", status);
    }

    status = tibemsConnectionFactory_SetServerURL(factory,serverUrl);
    if (status != TIBEMS_OK) 
    {
        fail("Error setting server url", status);
    }

    status = tibemsTopicConnectionFactory_CreateConnection(factory,&queueConnection,
                                                           userName,password);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueueConnection", status);
    }

    /* set the exception listener */
    status = tibemsConnection_SetExceptionListener(queueConnection,
            onException, NULL);
    if (status != TIBEMS_OK)
    {
        fail("Error setting exception listener", status);
    }

    /* create the queue */
    status = tibemsQueue_Create(&queue,queueName);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueue", status);
    }

    /* create the qcopy */
    status = tibemsQueue_Create(&qcopy, qcopyName);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueue", status);
    }

    /* create the queue session */
    status = tibemsQueueConnection_CreateQueueSession(queueConnection,
            &queueSession,TIBEMS_FALSE,TIBEMS_AUTO_ACKNOWLEDGE);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueueSession", status);
    }
            
    /* start the connection */
    status = tibemsConnection_Start(queueConnection);
    if (status != TIBEMS_OK)
    {
        fail("Error starting tibemsQueueConnection", status);
    }

    /*
     * create browser and browse what is there in the queue
     */
    printf("--- Copying the queue.\n");

    status = tibemsQueueSession_CreateBrowser(queueSession,
            &queueBrowser,queue,NULL);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueueBrowser", status);
    }    
    
    /* create the queue sender */
    status = tibemsQueueSession_CreateSender(queueSession,
            &qcopySender, qcopy);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueueSender", status);
    }

    while(1) 
    {
        /* get the next message */
        status = tibemsQueueBrowser_GetNext(queueBrowser,&msg);

        if (status == TIBEMS_NOT_FOUND)
            break;

        if (status != TIBEMS_OK)
        {
            fail("Error getting next message from tibemsQueueBrowser", status);
        }

        if(!msg) {
            printf("--- No more messages in the queue.\n");
            break;
	}

	/* Get messsage size - actual space that the wire format message occupies */
	status = tibemsMsg_GetByteSize(msg, &msgsize);
        if (status != TIBEMS_OK)
        {
            fail("Error getting message byte size", status);
        }

        browsec++;
	
        printf("\n>>> Copied message: number=%d; Message Size: %d bytes <<<\n",browsec, msgsize);
	if(dispmsg != 0) {
		printf(">>> Message Payload <<<\n");
		tibemsMsg_Print(msg);
	}

        /* send the message */
        status = tibemsQueueSender_Send(qcopySender,msg);
        if (status != TIBEMS_OK)
        {
            fail("Error sending tibemsMsg", status);
        }

        /* destroy the message */
        status = tibemsMsg_Destroy(msg);
        if (status != TIBEMS_OK)
        {
            fail("Error destroying tibemsMsg", status);
        }

	if((noofmsg != 0) && (browsec >= noofmsg))
	    break;
    }
            
    printf("--- Copied specified messages to the queue.\n");

    /*
     * close all and quit
     */
    closeAll();
}
    
/*-----------------------------------------------------------------------
 * main
 *----------------------------------------------------------------------*/
int main(int argc, char** argv)
{
    parseArgs(argc,argv);

    /* print parameters */
    printf("------------------------------------------------------------------------\n");
    printf("tibemsQueueCopy SAMPLE\n");
    printf("------------------------------------------------------------------------\n");
    printf("Server....................... %s\n",serverUrl?serverUrl:"localhost");
    printf("User......................... %s\n",userName?userName:"(null)");
    printf("Queue........................ %s\n",queueName);
    printf("QCopy........................ %s\n",qcopyName);
    printf("------------------------------------------------------------------------\n");

    run();

    return 1;
}
