/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : Properties.java                                      #
#                                                                              #
#       Description     : Defines properties required by the java EMS test     #
#                         harness                                              #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

// JMS interfaces or "common facilities"
import javax.jms.*;

// Standard Java libraries
import java.util.*;

public class Properties {
	// Broker and connection information
        public static String brokername;
	public static String url;
        public static String user;
        public static String password;
        public static String ProviderContextFactory;
        public static String DefaultProviderURL;
        public static String connfact;

	// Test Type
	public static String test;

	// Monitoring information
	public static String monitortopic;
	public static int noofmthread;

	// JMS parameters
	public static int noofconnections;
	public static int noofsessions;
	public static boolean transacted;
	public static int messagesize;
	public static int count;
	public static int time;
	public static int batch;
	public static String mode;

	// Destination information
        public static String type;
        public static String topic;
	public static int nooftopic;
	public static String queue;
	public static int noofqueue;

	// Publisher information
	public static int noofpub;
	public static int deliverymode;
	public static boolean dupmessage;
	public static long pubrate;

	// Subscriber information
	public static int noofsub;
	public static int ackmode;
	public static boolean durable;
	public static long subrate;

	public static void readProperties(String brokername) {
                // Open the properties file to obtain the node properties
                ResourceBundle setting = ResourceBundle.getBundle(brokername);

		// Broker and connection information
		brokername = setting.getString(Constant.BROKERNAME);
		url = setting.getString(Constant.URL);
                user = setting.getString(Constant.USER);
                password = setting.getString(Constant.PASSWORD);
                ProviderContextFactory = setting.getString(Constant.PROVIDER_CONTEXT_FACTORY);
                DefaultProviderURL = setting.getString(Constant.DEFAULT_PROVIDER_URL);
                connfact = setting.getString(Constant.CONNECTION_FACTORY);

		// Test Type
		test = setting.getString(Constant.TEST);

		// Monitoring information
		monitortopic = setting.getString(Constant.MONITOR_TOPIC);
		noofmthread = (new Integer(setting.getString(Constant.NO_OF_MTHREAD))).intValue();

		// JMS parameters
		noofconnections = (new Integer(setting.getString(Constant.NO_OF_CONNECTIONS))).intValue();
		noofsessions = (new Integer(setting.getString(Constant.NO_OF_SESSIONS))).intValue();
		transacted = (Boolean.valueOf(setting.getString(Constant.TRANSACTED))).booleanValue();
		messagesize = (new Integer(setting.getString(Constant.MESSAGE_SIZE))).intValue();
		count = (new Integer(setting.getString(Constant.COUNT))).intValue();
		time = (new Integer(setting.getString(Constant.TIME))).intValue();
		batch = (new Integer(setting.getString(Constant.BATCH))).intValue();
		mode = setting.getString(Constant.MODE);

		// Destination information
                type = setting.getString(Constant.TYPE);
                topic = setting.getString(Constant.TOPIC);
		nooftopic = (new Integer(setting.getString(Constant.NO_OF_TOPIC))).intValue();
                queue = setting.getString(Constant.QUEUE);
		noofqueue = (new Integer(setting.getString(Constant.NO_OF_QUEUE))).intValue();

		// Publisher information
		noofpub = (new Integer(setting.getString(Constant.NO_OF_PUB))).intValue();
		deliverymode = (setting.getString(Constant.DELIVERY_MODE)).equals(Constant.NONPERSISTENT) ? DeliveryMode.NON_PERSISTENT : (setting.getString(Constant.DELIVERY_MODE)).equals(Constant.PERSISTENT) ? DeliveryMode.PERSISTENT : com.tibco.tibjms.Tibjms.RELIABLE_DELIVERY;
		dupmessage = (Boolean.valueOf(setting.getString(Constant.DUP_MESSAGE))).booleanValue();
		pubrate = (new Long(setting.getString(Constant.PUB_RATE))).longValue();

		// Subscriber information
		noofsub = (new Integer(setting.getString(Constant.NO_OF_SUB))).intValue();
		ackmode = (setting.getString(Constant.ACK_MODE)).equals(Constant.AUTOACK) ? Session.AUTO_ACKNOWLEDGE : (setting.getString(Constant.ACK_MODE)).equals(Constant.DUPSOK) ? Session.DUPS_OK_ACKNOWLEDGE : com.tibco.tibjms.Tibjms.NO_ACKNOWLEDGE;
		durable = (Boolean.valueOf(setting.getString(Constant.DURABLE))).booleanValue();
		subrate = (new Long(setting.getString(Constant.SUB_RATE))).longValue();
	}
}

