/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : httpreqres.c                                         #
#                                                                              #
#       Description     : This utility is implemented to make HTTP Web Service #
#                         requests to register the creation, deletion and      #
#                         migration of a EMS broker instance in an environment.#
#                         This facilitates the EMS usage governance of broker  #
#                         instances in dev, qa, uat and prod environments      #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2005 Sep    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

/* Included Library */
#ifdef WIN32
    #include <winsock2.h>
#else
	#include <sys/types.h>
	#include <sys/socket.h>
	#include <sys/time.h>
	#include <unistd.h>
	#include <strings.h>
	#include <netdb.h>
	#include <string.h>
	#include <strings.h>
#endif

#include <stdio.h>
#include <errno.h>

#include <httpreqres.h> /* httpreqres constants */
			
int main(int argc, char *argv[]) {

	#ifdef WIN32
		WORD		wVerReq = MAKEWORD(2, 0); /* Specify Windows Socket version 2 */
		WSADATA		stWsaData; /* Details of the Windows Sockets implementation */
		SOCKET		iSockfd; /* socket descriptor */
		SOCKADDR_IN	strWSSvrAddr; /* Web Service information to which connection
								  is established */
		PHOSTENT	pHostEnt = NULL; /* IP Address of the Web Service */
		size_t		iCount = 0;
	#else
		int			iSockfd = 0; /* socket descriptor */
		struct		sockaddr_in	strWSSvrAddr; /* Web Service information to
											  which connection is established */
		struct		hostent *	pHostEnt = NULL; /* IP Address of the Web Service */
		int			iCount = 0;
	#endif
	char	szHttpData[HTTP_BUFF_SIZE]; /* HTTP payload */
	char *	pszWSSvr = NULL; /* Web Services Server */
	char *	pszWSSiteName = NULL; /* Web Services Site Name */
	char *	pszWSvcName = NULL; /* Web Services Name */
	int		iWSRetry = WS_RETRY; /* Web Service Retry count */
	int		iWSTimeout = WS_TIMEOUT; /* Web Services Time out (secs) */
	char *	pszOper = NULL; /* Requested Web Services operation */
	char *	pszData = NULL; /* Web Services data */
	char *	pszAppName = argv[0]; /* Application name */
	int		iLoop = 0; /* Loop variable */
	int		iRetVal = 0; /* Return value */
	int		iMaxfd = 0; /* Max socket descriptor value */
	fd_set	fdsRead; /* Read file descriptor set */
	struct timeval stTimeout; /* Time out for recv */

	/* Parse the input arguments */
	for(iLoop = 1; iLoop < argc ;) {
		if(!strcmp(argv[iLoop], "-wssvr")) {
			pszWSSvr = argv[++iLoop];
		} else if(!strcmp(argv[iLoop], "-wssiten")) {
			pszWSSiteName = argv[++iLoop];
		} else if(!strcmp(argv[iLoop], "-wsvcn")) {
			pszWSvcName = argv[++iLoop];
		} else if(!strcmp(argv[iLoop], "-wsrt")) {
			iWSRetry = atoi(argv[++iLoop]);
		} else if(!strcmp(argv[iLoop], "-wsto")) {
			iWSTimeout = atoi(argv[++iLoop]);
		} else if(!strcmp(argv[iLoop], "-oper")) {
			pszOper = argv[++iLoop];
		} else if(!strcmp(argv[iLoop], "-data")) {
			pszData = argv[++iLoop];
		}
		iLoop++;
	}

	/* If mandatory arguments are not specified */
	if(pszWSSvr == NULL || pszWSSiteName == NULL || pszWSvcName == NULL ||
		pszOper == NULL || pszData == NULL) { 
		printf("%s is the utility to register the creation, "
			"deletion and migration\n"
			"of a EMS broker instance in an environment. "
			"This facilitates the EMS usage\n"
			"governance of broker instances in dev, qa, uat "
			"and prod environments\n"
			"-wssvr(*)  : Server hostname hosting the Web Service\n"
			"-wssiten(*): Site name for the Web Service \n"
			"-wsvcn(*)  : Web Service name\n"
			"-wsrt      : Web Service re-try count\n"
			"-wsto      : Web Service time-out (secs) for each re-try\n"
			"-oper(*)   : Web Service operation to be executed\n"
			"             - CreateBroker\n"
			"             - CreateBrokerLicTyp\n"
			"             - DeleteBroker\n"
			"             - MigrateBroker\n"
			"-data(*)   : HTTP data in POST format\n\n"
			"(*)        : Mandatory arguments\n", argv[0]);

		exit(FAILURE);
	}

	#ifdef WIN32
		/* First call the WSAStartup function to specify the version of
		Windows Sockets required and retrieve details of the specific
		Windows Sockets implementation */
		if(WSAStartup(wVerReq, &stWsaData) != 0) {
			perror("WSAStartup()");
			exit(errno);
		}
	#endif

	/* Obtain a socket descriptor for Web Services HTTP communication */
	if((iSockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("socket()");
		exit(errno);
	}

	/* Obtain the IP address for the Web Services server */
	if((pHostEnt = gethostbyname(pszWSSvr)) == NULL) {
		perror("gethostbyname()");
		exit(errno);
	} 

	/* Initialize Web Services server connection information. Note that
	gethostbyname() returns the IP address in network byte order */
	#ifndef WIN32
		bzero(&strWSSvrAddr, sizeof(struct sockaddr_in));
	#endif
	strWSSvrAddr.sin_family			= AF_INET;
	strWSSvrAddr.sin_port			= htons(HTTP_PORT); 

	#ifdef WIN32
		memcpy((char FAR *)&(strWSSvrAddr.sin_addr.s_addr), pHostEnt->h_addr, pHostEnt->h_length);
	#else
		strWSSvrAddr.sin_addr.s_addr =
				((struct in_addr *)(*(pHostEnt->h_addr_list)))->s_addr;
	#endif

	/* Connect to the Web Services server */
	if(connect(iSockfd,
		(struct sockaddr *) &strWSSvrAddr,
		sizeof(struct sockaddr_in)) < 0 ) {
		perror("connect()");
		exit(errno);
	}

	/* Generate the WS HTTP request */
	sprintf(szHttpData, "POST /%s/%s/%s HTTP/1.1\r\n\
Host: %s\r\n\
Content-Type: application/x-www-form-urlencoded\r\n\
Content-Length: %d\r\n\r\n\
%s", pszWSSiteName, pszWSvcName, pszOper, pszWSSvr, strlen(pszData), pszData);

	/* Send request to the Web Services */
	if((iCount = send(iSockfd, szHttpData, strlen(szHttpData), 0)) <  0) {
			perror("send()");
			exit(errno);
	}

	fprintf(stdout, "***WS HTTP Request***:\n%s\nCount: %d\n\n", szHttpData, iCount);

	for(iLoop = 0; iLoop < iWSRetry; iLoop++) {
		iMaxfd = (int)iSockfd + 1;
		FD_ZERO(&fdsRead);
		FD_SET(iSockfd, &fdsRead);

		stTimeout.tv_sec = iWSTimeout;
		stTimeout.tv_usec = 0;

		iRetVal = select(iMaxfd,
						&fdsRead,
						(fd_set *)0,
						(fd_set *)0,
						(struct timeval *)&stTimeout) ;

		if(iRetVal < 0) { /* Error */
			perror("select()");
			exit(errno);
		} else if(iRetVal == 0) { /* 'select' for 'recv' Timed out */
			fprintf(stdout, "***WS HTTP re-try attempt %d of %d***\n", iLoop+1, iWSRetry);			
			continue;
		} else if(FD_ISSET(iSockfd, &fdsRead)) { /* Response available from Web Services */
			/* Receive the Web Services response */
			if((iCount = recv(iSockfd, szHttpData, HTTP_BUFF_SIZE, 0)) < 0) {
				perror("recv()");
				exit(errno);
			}

			/* Null terminate the HTTP data */
			szHttpData[iCount] = '\0';
			fprintf(stdout, "***WS HTTP Response***:\n%s\nCount: %d\n\n", szHttpData, iCount);

			/* Check if requested Web Services operation returned successfully. A successfull
			response should contain "sql_code=0" */
			if(strstr(szHttpData, WS_SUCCESS) != NULL) {
				break;
			} else {
				exit(FAILURE);
			}
		}
	}

	/* If number of Web Services retry is exhausted */
	if(iLoop == iWSRetry) {
		fprintf(stdout, "***WS HTTP Timed Out***\n");
	}

	#ifdef WIN32
		closesocket(iSockfd); /* Close socket connection */
		WSACleanup(); /* Terminate use of the WS2_32.DLL */
	#else
		close(iSockfd); /* Close socket connection */
	#endif

	/* Exit successfully */
	exit(SUCCESS);
}

