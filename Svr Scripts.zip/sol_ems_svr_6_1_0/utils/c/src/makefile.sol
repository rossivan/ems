# Initialize environment variables
EMS_INSTALL=/app/ems

# Set the EMS library version
version=6.1.0

tibemsMsgProducerPerf : tibemsMsgProducerPerf.o tibemsUtilities.o
	gcc tibemsMsgProducerPerf.o tibemsUtilities.o ${EMS_INSTALL}/${version}/clients/c/lib/libtibems.a ${EMS_INSTALL}/${version}/clients/c/lib/libtibemslookup.a ${EMS_INSTALL}/${version}/clients/c/lib/libldap.a ${EMS_INSTALL}/${version}/clients/c/lib/liblber.a ${EMS_INSTALL}/${version}/clients/c/lib/liblutil.a ${EMS_INSTALL}/${version}/clients/c/lib/libxml2.a ${EMS_INSTALL}/${version}/clients/c/lib/libssl.a ${EMS_INSTALL}/${version}/clients/c/lib/libcrypto.a ${EMS_INSTALL}/${version}/clients/c/lib/libz.a -lsocket -lgen -lnsl -lresolv -lthread -o tibemsMsgProducerPerf
	mv tibemsMsgProducerPerf ..

tibemsMsgProducerPerf.o : tibemsMsgProducerPerf.c
	gcc -g -I. -I${EMS_INSTALL}/${version}/clients/c/include -c tibemsMsgProducerPerf.c

tibemsMsgConsumerPerf : tibemsMsgConsumerPerf.o tibemsUtilities.o
	gcc tibemsMsgConsumerPerf.o tibemsUtilities.o ${EMS_INSTALL}/${version}/clients/c/lib/libtibems.a ${EMS_INSTALL}/${version}/clients/c/lib/libtibemslookup.a ${EMS_INSTALL}/${version}/clients/c/lib/libldap.a ${EMS_INSTALL}/${version}/clients/c/lib/liblber.a ${EMS_INSTALL}/${version}/clients/c/lib/liblutil.a ${EMS_INSTALL}/${version}/clients/c/lib/libxml2.a ${EMS_INSTALL}/${version}/clients/c/lib/libssl.a ${EMS_INSTALL}/${version}/clients/c/lib/libcrypto.a ${EMS_INSTALL}/${version}/clients/c/lib/libz.a -lsocket -lgen -lnsl -lresolv -lthread -o tibemsMsgConsumerPerf
	mv tibemsMsgConsumerPerf ..

tibemsMsgConsumerPerf.o : tibemsMsgConsumerPerf.c
	gcc -g -I. -I${EMS_INSTALL}/${version}/clients/c/include -c tibemsMsgConsumerPerf.c

tibemsQueueBrowser : tibemsQueueBrowser.o
	gcc tibemsQueueBrowser.o ${EMS_INSTALL}/${version}/clients/c/lib/libtibems.a ${EMS_INSTALL}/${version}/clients/c/lib/libtibemslookup.a ${EMS_INSTALL}/${version}/clients/c/lib/libldap.a ${EMS_INSTALL}/${version}/clients/c/lib/liblber.a ${EMS_INSTALL}/${version}/clients/c/lib/liblutil.a ${EMS_INSTALL}/${version}/clients/c/lib/libxml2.a ${EMS_INSTALL}/${version}/clients/c/lib/libssl.a ${EMS_INSTALL}/${version}/clients/c/lib/libcrypto.a ${EMS_INSTALL}/${version}/clients/c/lib/libz.a -lsocket -lgen -lnsl -lresolv -lthread -o tibemsQueueBrowser
	mv tibemsQueueBrowser ..

tibemsQueueBrowser.o : tibemsQueueBrowser.c
	gcc -g -I${EMS_INSTALL}/${version}/clients/c/include -c tibemsQueueBrowser.c

tibemsQueueCopy : tibemsQueueCopy.o
	gcc tibemsQueueCopy.o ${EMS_INSTALL}/${version}/clients/c/lib/libtibems.a ${EMS_INSTALL}/${version}/clients/c/lib/libtibemslookup.a ${EMS_INSTALL}/${version}/clients/c/lib/libldap.a ${EMS_INSTALL}/${version}/clients/c/lib/liblber.a ${EMS_INSTALL}/${version}/clients/c/lib/liblutil.a ${EMS_INSTALL}/${version}/clients/c/lib/libxml2.a ${EMS_INSTALL}/${version}/clients/c/lib/libssl.a ${EMS_INSTALL}/${version}/clients/c/lib/libcrypto.a ${EMS_INSTALL}/${version}/clients/c/lib/libz.a -lsocket -lgen -lnsl -lresolv -lthread -o tibemsQueueCopy
	mv tibemsQueueCopy ..

tibemsQueueCopy.o : tibemsQueueCopy.c
	gcc -g -I${EMS_INSTALL}/${version}/clients/c/include -c tibemsQueueCopy.c

tibemsTopicBrowser : tibemsTopicBrowser.o
	gcc tibemsTopicBrowser.o ${EMS_INSTALL}/${version}/clients/c/lib/libtibems.a ${EMS_INSTALL}/${version}/clients/c/lib/libtibemslookup.a ${EMS_INSTALL}/${version}/clients/c/lib/libldap.a ${EMS_INSTALL}/${version}/clients/c/lib/liblber.a ${EMS_INSTALL}/${version}/clients/c/lib/liblutil.a ${EMS_INSTALL}/${version}/clients/c/lib/libxml2.a ${EMS_INSTALL}/${version}/clients/c/lib/libssl.a ${EMS_INSTALL}/${version}/clients/c/lib/libcrypto.a ${EMS_INSTALL}/${version}/clients/c/lib/libz.a -lsocket -lgen -lnsl -lresolv -lthread -o tibemsTopicBrowser
	mv tibemsTopicBrowser ..

tibemsTopicBrowser.o : tibemsTopicBrowser.c
	gcc -g -I${EMS_INSTALL}/${version}/clients/c/include -c tibemsTopicBrowser.c

tibemsTopicCopy : tibemsTopicCopy.o
	gcc tibemsTopicCopy.o ${EMS_INSTALL}/${version}/clients/c/lib/libtibems.a ${EMS_INSTALL}/${version}/clients/c/lib/libtibemslookup.a ${EMS_INSTALL}/${version}/clients/c/lib/libldap.a ${EMS_INSTALL}/${version}/clients/c/lib/liblber.a ${EMS_INSTALL}/${version}/clients/c/lib/liblutil.a ${EMS_INSTALL}/${version}/clients/c/lib/libxml2.a ${EMS_INSTALL}/${version}/clients/c/lib/libssl.a ${EMS_INSTALL}/${version}/clients/c/lib/libcrypto.a ${EMS_INSTALL}/${version}/clients/c/lib/libz.a -lsocket -lgen -lnsl -lresolv -lthread -o tibemsTopicCopy
	mv tibemsTopicCopy ..

tibemsTopicCopy.o : tibemsTopicCopy.c
	gcc -g -I${EMS_INSTALL}/${version}/clients/c/include -c tibemsTopicCopy.c

tibemsUtilities.o : tibemsUtilities.c
	gcc -g -I. -I${EMS_INSTALL}/${version}/clients/c/include -c tibemsUtilities.c

httpreqres : httpreqres.o
	gcc -lsocket -lnsl -o httpreqres httpreqres.o
	mv httpreqres ..

httpreqres.o : httpreqres.c
	gcc -c -I. httpreqres.c

dsksynr : dsksynr.o
	gcc -o dsksynr dsksynr.o
	mv dsksynr ..

dsksynr.o : dsksynr.c
	gcc -c dsksynr.c

clean :
	rm -rf *.o
