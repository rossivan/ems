/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : Sub.java                                             #
#                                                                              #
#       Description     : The subscriber code for the java EMS test harness    #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#       2004 Aug    1.1         Roshan D'Mello  Set the appropriate unique     #
#                                               client-id                      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

// JMS interfaces or "common facilities"
import javax.jms.*;

// JNDI lookup interfaces
import javax.naming.*;

// Standard Java libraries
import java.util.*;

public class Sub implements Runnable {
	private Hashtable env;
	private InitialContext SubInitialContext; // For JNDI lookup
	private long start;
	private long stop;
        private long lstart; // Latency start
        private long lstop; // Latency stop
        private long lmin=Constant.TIME_MAX; // Latency minimum
        private long lmax=Constant.TIME_MIN; // Latency maximum
        private long lavg=0; // Latency average
	private long ldiff;
	private int ThreadId;
	private String destination;
	private int noofdest;
	private int connindex;

	private ConnectionFactory SubConnectionFactory;
	private static Connection SubConnection[];
	private Session SubSession;
        private Destination SubDest;
	private MessageConsumer SubMessageConsumer;

	private synchronized int getConnectionIndex(InitialContext SubInitialContext, int ThreadId) {
		if(SubConnection == null) {
			SubConnection = new Connection[Properties.noofconnections];
		}

		connindex =
			((ThreadId % Properties.noofsessions) != 0) ?
			ThreadId / Properties.noofsessions :
			(ThreadId / Properties.noofsessions) - 1;

		if(SubConnection[connindex] == null) {
			try {
				SubConnectionFactory = (ConnectionFactory) SubInitialContext.lookup(Properties.connfact);
				SubConnection[connindex] = SubConnectionFactory.createConnection(Properties.user, Properties.password);
				SubConnection[connindex].setClientID((getClass()).getName() + this.ThreadId + (Properties.type.equals(Constant.TOPIC) ? Properties.topic : Properties.queue) + System.currentTimeMillis());
			} catch(NamingException e) {
				e.printStackTrace();
			} catch(JMSException e) {
				e.printStackTrace();
			}
		}

		return connindex;
	}

	private Sub(int ThreadId) {
		this.ThreadId = ThreadId;

		// Setup the initial context environment for JNDI lookup
		env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, Properties.ProviderContextFactory);
		env.put(Context.PROVIDER_URL, Properties.DefaultProviderURL);	
		env.put(Context.SECURITY_PRINCIPAL, Properties.user);
		env.put(Context.SECURITY_CREDENTIALS, Properties.password);

		try {
			SubInitialContext = new InitialContext(env);	
			connindex = getConnectionIndex(SubInitialContext, ThreadId);
			SubSession = SubConnection[connindex].createSession(Properties.transacted, Properties.ackmode);

			if(Properties.type.equals(Constant.TOPIC)) {
				noofdest = Properties.nooftopic;
                                destination = Properties.topic;
                        } else {
				noofdest = Properties.noofqueue;
                                destination = Properties.queue;
                        }

			if(Properties.type.equals(Constant.TOPIC)) {
                		if(noofdest == 1) { // topic per subscriber
					destination = Properties.topic + this.ThreadId;
				} else if(noofdest > 1) { // topic wild card
					destination = Properties.topic + Constant.UNIVERSAL_TOPIC;
				} else {
					destination = Properties.topic;
				}
			} else {
                                if(noofdest == 1) { // queue per subscriber
                                        destination = Properties.queue + this.ThreadId;
                                } else { // load balanced queue
                                        destination = Properties.queue;
                                }
			}

			try {
				SubDest = (Destination) SubInitialContext.lookup(destination);
			} catch(Exception e) {
				if(Properties.type.equals(Constant.TOPIC)) {
					SubDest = (Destination) SubSession.createTopic(destination);
				} else {
					SubDest = (Destination) SubSession.createQueue(destination);
				}	
			}

			if(Properties.durable && Properties.type.equals(Constant.TOPIC)) {
				SubMessageConsumer = SubSession.createDurableSubscriber((Topic)SubDest, Properties.topic);
			} else {
				SubMessageConsumer = SubSession.createConsumer(SubDest);
			}
		} catch(NamingException e) {
			e.printStackTrace();
		} catch(JMSException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		Message SubMessage;
		int	iLoop;

		try {
			SubConnection[connindex].start();

			for(iLoop=0; iLoop < Properties.count;) {
				SubMessage = SubMessageConsumer.receive();

				lavg += ldiff = (System.currentTimeMillis() - SubMessage.getLongProperty(Constant.PUB_TIME));
				SubMessage.getStringProperty(Constant.MSG_SEQ_NO);
				if(ldiff < lmin) {
                                        lmin = ldiff;
                                } else if(ldiff > lmax) {
                                        lmax = ldiff;
                                }
	
				// Sample the start time for the first message
				if(iLoop == 0) {
					start = System.currentTimeMillis();
				}

				if(SubMessage == null) {
					break;	
				}

				// displayMessage(SubMessage);

				iLoop++;
				if(SubSession.getTransacted() && (iLoop % Properties.batch == 0)) {
					SubSession.commit();
				}
			}

                        // Commit the transacted session for remainder messages
                        if(SubSession.getTransacted() && (Properties.count % Properties.batch != 0)) {
                                SubSession.commit();
                        }

			stop = System.currentTimeMillis();
			System.out.println((getClass()).getName() + ThreadId + "[" + (new Date(stop)).toString() + "] -> Messages : " + iLoop + ", Seconds : " + ((double)stop-(double)start)/(double)Constant.SEC + ", Message/Second : " + ((float)iLoop/(float)(stop-start))*(float)Constant.SEC + ", Latency (ms) : " + (float)lavg/(float)iLoop + " (Avg), " + lmin + " (Min), " + lmax + " (Max)\n");

                        // For test type "recovery" simulate a database hang
                        if(Properties.test.equals(Constant.TEST_RECOVERY)) {
                                try {
					System.out.println("Sleeping -> Sub" + ThreadId);
                                        Thread.sleep(Constant.DAY);
                                } catch (InterruptedException e) {
                                }
                        }

			// Close MessageConsumer, Session, Connection
			try {
				Thread.sleep(Properties.subrate);
			} catch (InterruptedException e) {
			}
			SubMessageConsumer.close();
			if(Properties.durable && Properties.type.equals(Constant.TOPIC)){
				SubSession.unsubscribe(Properties.topic);	
			}
			SubSession.close();
		} catch(JMSException e) {
			e.printStackTrace();
                }
	}

	private void displayMessage(Message SubMessage) {
	}

	public static void main(String args[]) {
		int     iLoop;

                Properties.readProperties(args[0]);

		for(iLoop=0; iLoop < Properties.noofsub; iLoop++) {
			Sub s = new Sub(iLoop+1);
			Thread t = new Thread(s);
			if(Properties.count != 0) t.start();
		}
	}
}

