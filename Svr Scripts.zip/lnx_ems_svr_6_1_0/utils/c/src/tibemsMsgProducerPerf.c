/*-#-+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*
*                                                                              *
*       File Name       : tibemsMsgProducerPerf.c                              *
*                                                                              *
*       Description     : This tool produces/publishes messages to a queue/    *
*                         topic respectively                                   *
*                                                                              *
*       EMS Version     : 4.0.0                                                *
*       Supported         4.1.0                                                *
*                         4.2.1 (Not Released)                                 *
*                         4.3.0                                                *
*                         4.4.0 (Not Released)                                 *
*                         4.4.1                                                *
*                         4.4.3                                                *
*                         5.1.4 (Not Released)                                 *
*                         6.0.0 (Not Released)                                 *
*                         6.0.1                                                *
*                         6.1.0                                                *
*                                                                              *
*       Maintenance Log :                                                      *
*                                                                              *
*       Date        Version     Programmer      Description                    *
*       ----------- -------     --------------  ----------------------------   *
*       2008 Jun    1.0         Roshan D'Mello  Creation of original file      *
*                                                                              *
*---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*/


/* 
 * Copyright 2001-2006 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 * 
 * $Id: tibemsMsgProducerPerf.c 23546 2006-10-27 00:13:21Z $
 * 
 */

/*
 * Usage:  tibemsMsgProducerPerf [options]
 *
 *  where options are:
 *
 *   -server       <url>         EMS server URL. Default is
 *                               "tcp://localhost:7222".
 *   -user         <username>    User name. Default is null.
 *   -password     <password>    User password. Default is null.
 *   -topic        <topic-name>  Topic name. Default is "topic.sample".
 *   -queue        <queue-name>  Queue name. No default.
 *   -size         <num bytes>   Message payload size in bytes. Default is 100.
 *   -count        <num msgs>    Number of messages to send. Default is 10k.
 *   -time         <seconds>     Number of seconds to run. Default is 0.
 *   -delivery     <mode>        Delivery mode. Default is NON_PERSISTENT.
 *                               Other values: PERSISTENT and RELIABLE.
 *   -threads      <num threads> Number of producer threads. Default is 1.
 *   -connections  <num conns>   Number of producer connections. Default is 1.
 *   -txnsize      <num msgs>    Number of nessages per transaction. Default 0.
 *   -rate         <msg/sec>     Message rate for producer threads.
 *   -payload      <file name>   File containing message payload.
 *   -uniquedests                Each producer thread uses a unique destination.
 *   -compression                Enable message compression.
 */

#include <tibems/tibems.h>
#include <limits.h>
#include <sys/timeb.h>

#include "tibemsUtilities.h"

typedef struct _runArgs
{
    tibemsConnection connection;
    int              number;
    int              count;
    long int         start;
    long int         stop;
} runArgs;

/*-----------------------------------------------------------------------
 * Parameters
 *----------------------------------------------------------------------*/
char*       serverUrl      = "tcp://localhost:7222";
char*       username       = NULL;
char*       password       = NULL;
char*       destination    = "topic.sample";
char*       payloadFile    = NULL;
int         txnSize        = 0;
int         count          = 10000;
int         runTime        = 0;
int         threads        = 1;
int         connections    = 1;
int         deliveryMode   = TIBEMS_NON_PERSISTENT;
int         msgSize        = 0;
int         msgRate        = 0;
tibems_bool useUniqueDests = TIBEMS_FALSE;
tibems_bool useTopic       = TIBEMS_TRUE;
tibems_bool useCompression = TIBEMS_FALSE;

/*---------------------------------------------------------------------
 * fail
 *---------------------------------------------------------------------*/
void fail(const char* message, tibems_status s)
{
    const char* msg = tibemsStatus_GetText(s);
    printf("ERROR: %s\n", message);
    printf("\tSTATUS: %d %s\n", s, msg ? msg : "(Undefined Error)");
    exit(1);
}

/*-----------------------------------------------------------------------
 * usage
 *----------------------------------------------------------------------*/
void usage() 
{
    printf("\nUsage: tibemsMsgProducerPerf [options]\n");
    printf("\n");
    printf("   where options are:\n");
    printf("\n");
    printf(" -server       <url>         Server URL. Default is \"tcp://localhost:7222\".\n");
    printf(" -user         <username>    User name. Default is null.\n");
    printf(" -password     <password>    User password. Default is null.\n");
    printf(" -topic        <name>        Topic name. Default is \"topic.sample\".\n");
    printf(" -queue        <name>        Queue name. No default.\n");
    printf(" -size         <bytes>       Message payload size in bytes. Default is 0.\n");
    printf(" -delivery     <mode>        Delivery mode: RELIABLE, NON_PERSISTENT, PERSISTENT\n");
    printf("                             Default is NON_PERSISTENT.\n");
    printf(" -txnsize      <num msgs>    Number of messages per transaction.\n");
    printf(" -count        <num msgs>    Number of messages to receive.\n");
    printf(" -time         <seconds>     Number of seconds to run.\n");
    printf(" -threads      <num threads> Number of producer threads.\n");
    printf(" -connections  <num conns>   Number of connections.\n");
    printf(" -rate         <msg/sec>     Message rate for producer threads.\n");
    printf(" -payload      <filename>    File containing message payload.\n");
    printf(" -uniquedests                Each producer uses a unique destination.\n");
    printf(" -compression                Enable message compression.\n");
    exit(0);
}

/*-----------------------------------------------------------------------
 * parseArgs
 *----------------------------------------------------------------------*/
void parseArgs(int argc, char** argv) 
{
    int i=1;

    while (i < argc)
    {
        if (!argv[i])
        {
            i += 1;
        }
        else if (strcmp(argv[i],"-help")==0)
        {
            usage();
        }
        else if (strcmp(argv[i],"-server")==0)
        {
            if ((i+1) >= argc) usage();
            serverUrl = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-user")==0)
        {
            if ((i+1) >= argc) usage();
            username = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-password")==0)
        {
            if ((i+1) >= argc) usage();
            password = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-topic")==0)
        {
            if ((i+1) >= argc) usage();
            destination = argv[i+1];
            useTopic = TIBEMS_TRUE;
            i += 2;
        }
        else if (strcmp(argv[i],"-queue")==0)
        {
            if ((i+1) >= argc) usage();
            destination = argv[i+1];
            useTopic = TIBEMS_FALSE;
            i += 2;
        }
        else if (strcmp(argv[i],"-size")==0)
        {
            if ((i+1) >= argc) usage();
            msgSize = atoi(argv[i+1]);
            if (msgSize < 0)
            {
                printf("Invalid value for -size: %s\n", argv[i+1]);
                usage();
            }
            i += 2;
        }
        else if (strcmp(argv[i],"-delivery")==0)
        {
            if ((i+1) >= argc) usage();
            if (strcmp(argv[i+1], "RELIABLE") == 0)
            {
                deliveryMode = TIBEMS_RELIABLE;
            }
            else if (strcmp(argv[i+1], "NON_PERSISTENT") == 0)
            {
                deliveryMode = TIBEMS_NON_PERSISTENT;
            }
            else if (strcmp(argv[i+1], "PERSISTENT") == 0)
            {
                deliveryMode = TIBEMS_PERSISTENT;
            }
            else
            {
                printf("Invalid value for -delivery: %s\n", argv[i+1]);
                usage();
            }
            i += 2;
        }
        else if (strcmp(argv[i],"-txnsize")==0)
        {
            if ((i+1) >= argc) usage();
            txnSize = atoi(argv[i+1]);
            i += 2;
        }
        else if (strcmp(argv[i],"-count")==0)
        {
            if ((i+1) >= argc) usage();
            count = atoi(argv[i+1]);
            i += 2;
        }
        else if (strcmp(argv[i],"-time")==0)
        {
            if ((i+1) >= argc) usage();
            runTime = atoi(argv[i+1]);
            i += 2;
        }
        else if (strcmp(argv[i],"-threads")==0)
        {
            if ((i+1) >= argc) usage();
            threads = atoi(argv[i+1]);
            if (threads < 1)
            {
                printf("Invalid value for -threads: %s\n", argv[i+1]);
                usage();
            }
            i += 2;
        }
        else if (strcmp(argv[i],"-connections")==0)
        {
            if ((i+1) >= argc) usage();
            connections = atoi(argv[i+1]);
            if (connections < 1)
            {
                printf("Invalid value for -connections: %s\n", argv[i+1]);
                usage();
            }
            i += 2;
        }
        else if (strcmp(argv[i],"-rate")==0)
        {
            if ((i+1) >= argc) usage();
            msgRate = atoi(argv[i+1]);
            i += 2;
        }
        else if (strcmp(argv[i],"-payload")==0)
        {
            if ((i+1) >= argc) usage();
            payloadFile = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-uniquedests")==0)
        {
            useUniqueDests = TIBEMS_TRUE;
            i += 1;
        }
        else if (strcmp(argv[i],"-compression")==0)
        {
            useCompression = TIBEMS_TRUE;
            i += 1;
        }
        else
        {
            printf("Unrecognized parameter: %s\n",argv[i]);
            usage();
        }
    }
}

/*---------------------------------------------------------------------
 * delivery mode to string
 *---------------------------------------------------------------------*/
char* deliveryModeToString(int delmode)
{
    switch (delmode)
    {
    case TIBEMS_RELIABLE:
        return "RELIABLE";
    case TIBEMS_NON_PERSISTENT:
        return "NON_PERSISTENT";
    case TIBEMS_PERSISTENT:
        return "PERSISTENT";
    default:
        return "(unknown)";
    }
}

/*---------------------------------------------------------------------
 * current time in milliseconds
 *---------------------------------------------------------------------*/
long int currentMillis()
{
    struct timeb current;
    long int result;

    ftime(&current);
    result = current.time * 1000 + current.millitm;
    return result;
}

/*---------------------------------------------------------------------
 * create destination
 *---------------------------------------------------------------------*/
void createDestination(int num, tibemsDestination* dest)
{
    tibems_status status;
    char*         tmpStr;

    if (useUniqueDests == TIBEMS_TRUE)
    {
        tmpStr = (char*)malloc(strlen(destination)+17);
        sprintf(tmpStr, "%s.%d", destination, num);
    }
    else
    {
        tmpStr = strdup(destination);
    }

    if (useTopic == TIBEMS_TRUE)
    {
        status = tibemsTopic_Create(dest, tmpStr);
    }
    else
    {
        status = tibemsQueue_Create(dest, tmpStr);
    }

    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsDestination", status);
    }

    free(tmpStr);
}

/*-----------------------------------------------------------------------
 * create the message
 *----------------------------------------------------------------------*/
void createMessage(tibemsMsg* msg)
{
    tibems_status status;
    char*         bytes = 0;

    status = tibemsBytesMsg_Create(msg);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsMsg", status);
    }

    if (payloadFile)
    {
        FILE* file;
	
	file = fopen(payloadFile, "rb");
        if (file == NULL)
	{
	    printf("Error opening %s: %s\n", payloadFile, strerror(errno));
	}
	else
	{
	    fseek(file, 0L, SEEK_END);
	    msgSize = ftell(file);
	    rewind(file);
	    bytes = malloc(msgSize);
	    fread(bytes, msgSize, 1, file);
	    fclose(file);
	}

    } 
    else if (msgSize > 0)
    {
        int i;
        char c = 'A';
        bytes = malloc(msgSize);
        for (i = 0; i < msgSize; i++)
        {
            bytes[i] = c++;
            if (c > 'z')
                c = 'A';
        }
    }

    if (bytes)
    {
        status = tibemsBytesMsg_WriteBytes(*msg, bytes, msgSize);
        if (status != TIBEMS_OK)
        {
            fail("Error writing bytes to message", status);
        }
    }
}

/*---------------------------------------------------------------------
 * run test
 *---------------------------------------------------------------------*/
THREAD_RETVAL run(void* a)
{
    runArgs*          args = (runArgs*) a;
    struct timeb      currentTime, lastTime;
    tibemsDestination dest;
    tibemsSession     session;
    tibemsMsgProducer producer;
    tibemsMsg         msg;
    tibems_status     status;
    long int          remaining = 0;
    int               msgCount = 0;
    /* for message rate checking */
    long int          sampleStart = 0;
    int               sampleTime = 10;
    int               sampleCount = 0;

    tibems_Sleep(500);

    /* create the destination */
    createDestination(args->number, &dest);

    /* create the session */
    status = tibemsConnection_CreateSession(args->connection, 
                                            &session,
                                            txnSize > 0 ? TIBEMS_TRUE : TIBEMS_FALSE,
                                            TIBEMS_AUTO_ACKNOWLEDGE);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsSession", status);
    }

    /* create the producer */
    status = tibemsSession_CreateProducer(session,
                                          &producer,
                                          dest);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsMsgProducer", status);
    }

    /* set the delivery mode */
    status = tibemsMsgProducer_SetDeliveryMode(producer,
                                               deliveryMode);
    if (status != TIBEMS_OK)
    {
        fail("Error setting delivery mode", status);
    }

    /* performance settings */
    status = tibemsMsgProducer_SetDisableMessageID(producer, 
                                                   TIBEMS_TRUE) ||
             tibemsMsgProducer_SetDisableMessageTimestamp(producer,
                                                          TIBEMS_TRUE);
    if (status != TIBEMS_OK)
    {
        fail("Error configuring tibemsMsgProducer", status);
    }

    /* create the message */
    createMessage(&msg);

    if (useCompression == TIBEMS_TRUE)
    {
        status = tibemsMsg_SetBooleanProperty(msg, 
                                              "JMS_TIBCO_COMPRESS", 
                                              TIBEMS_TRUE);
        if (status != TIBEMS_OK)
        {
            fail("Error setting compression property", status);
        }
    }

    /* start timing */
    args->start = currentMillis();

    if (runTime > 0)
    {
        remaining = runTime * 1000;
        ftime(&lastTime);
    }

    /* process messages */
    while (count == 0 || msgCount < (count/threads))
    {
        /* receive next message */
        if (runTime > 0)
        {
            if (remaining <= 0)
            {
                break;
            }

            status = tibemsMsgProducer_Send(producer, msg);
            ftime(&currentTime);
            remaining -= ((currentTime.time - lastTime.time)*1000) + 
                         (currentTime.millitm - lastTime.millitm);
            lastTime = currentTime;
        }
        else
        {
            status = tibemsMsgProducer_Send(producer, msg);
        }

        if (status != TIBEMS_OK)
        {
            fail("Error sending message", status);
        }

        msgCount++;

        /* commit transactions as necessary */
        if (txnSize > 0 && (msgCount % txnSize == 0))
        {
            status = tibemsSession_Commit(session);
            if (status != TIBEMS_OK)
            {
                fail("Error committing transaction", status);
            }
        }

        /* check message rate */
        if (msgRate > 0)
	{
            if (msgRate < 100)
            {
                if (msgCount % 10 == 0)
	        {
	            long int sleepval = (long int)((10.0/msgRate)*1000);
	            tibems_Sleep(sleepval);
	        }
            }
            else
            {
                long int elapsed = currentMillis() - sampleStart;
	        if (elapsed >= sampleTime)
	        {
	            int actualMsgs = msgCount - sampleCount;
	            int expectedMsgs = (int)(elapsed*(msgRate/1000.0));
	            if (actualMsgs > expectedMsgs)
	            {
	                long int sleepval = (long int)(actualMsgs-expectedMsgs)/(msgRate/1000.0);
                        tibems_Sleep(sleepval);
                        if (sampleTime > 20)
                            sampleTime -= 10;
	            }
	            else
	            {
	                if (sampleTime < 300)
		            sampleTime += 10;
	            }
	            sampleStart = currentMillis();
	            sampleCount = msgCount;
	        }
            }
        }
    }

    /* commit any outstanding messages */
    if (txnSize > 0)
    {
        status = tibemsSession_Commit(session);
        if (status != TIBEMS_OK)
        {
            fail("Error committing transaction", status);
        }
    }

    /* stop timing */
    args->stop = currentMillis();
    args->count = msgCount;

    /* destroy the message */
    status = tibemsMsg_Destroy(msg);
    if (status != TIBEMS_OK)
    {
        fail("Error destroying tibemsMsg", status);
    }

    /* close the producer */
    status = tibemsMsgProducer_Close(producer);
    if (status != TIBEMS_OK)
    {
        fail("Error closing tibemsMsgProducer", status);
    }

    /* destroy destination */
    status = tibemsDestination_Destroy(dest);
    if (status != TIBEMS_OK)
    {
        fail("Error destroying tibemsDestination", status);
    }

    return 0;
}

/*-----------------------------------------------------------------------
 * main
 *----------------------------------------------------------------------*/
int main(int argc, char** argv)
{
    runArgs*          threadArgs;
    THREAD_OBJ*       threadArray;
    tibemsConnection* connArray;
    tibems_status     status = TIBEMS_OK;
    int               i;
    int               total = 0;
    int               rate;
    long int          start = LONG_MAX;
    long int          stop = LONG_MIN;
    tibemsConnectionFactory  factory  = NULL;

    /* parse arguments */
    parseArgs(argc,argv);

    printf("------------------------------------------------------------------------\n");
    printf("tibemsMsgProducerPerf\n");
    printf("------------------------------------------------------------------------\n");
    printf("Server....................... %s\n", serverUrl != NULL ? serverUrl : "localhost");
    printf("User......................... %s\n", username != NULL ? username : "(NULL)");
    printf("Destination.................. %s\n", destination != NULL ? destination : "(NULL)");
    if (payloadFile)
        printf("Message Size................. %s\n", payloadFile);
    else
        printf("Message Size................. %d\n", msgSize);
    printf("Producer Threads............. %d\n", threads);
    printf("Producer Connections......... %d\n", connections);
    printf("Delivery Mode................ %s\n", deliveryModeToString(deliveryMode));
    printf("Compression.................. %s\n", useCompression == TIBEMS_TRUE ? "TRUE" : "FALSE");
    if (txnSize > 0)
    {
        printf("Transaction Size............. %d\n", txnSize);
    }
    printf("------------------------------------------------------------------------\n\n");

    printf("Publishing to destination '%s'\n\n", destination);

    factory = tibemsConnectionFactory_Create();
    if (!factory)
    {
        printf("Error creating tibemsConnectionFactory\n");
    }

    status = tibemsConnectionFactory_SetServerURL(factory,serverUrl);
    if (status != TIBEMS_OK) 
    {
        fail("Error setting server url", status);
    }

    /* create the connections */
    connArray = (tibemsConnection*)malloc(sizeof(tibemsConnection)*connections);
    for (i = 0; i < connections; i++)
    {
        status = tibemsConnectionFactory_CreateConnection(factory,&connArray[i],
                                                          username,password);
        if (status != TIBEMS_OK)
        {
            fail("Error creating tibemsConnection", status);
        }
    }

    /* start the threads */
    threadArgs = (runArgs*)malloc(sizeof(runArgs)*threads);
    threadArray = (THREAD_OBJ*)malloc(sizeof(THREAD_OBJ)*threads);
    for (i = 0; i < threads; i++)
    {
        threadArgs[i].connection = connArray[i % connections];
        threadArgs[i].number = i+1;
        THREAD_CREATE(threadArray[i], &run, &threadArgs[i]);
    }

    /* wait for completion */
    ThreadJoin(threads, threadArray);

    /* gather rates */
    for (i = 0; i < threads; i++)
    {
        total += threadArgs[i].count;
        if (threadArgs[i].start < start)
        {
            start = threadArgs[i].start;
        }
        if (threadArgs[i].stop > stop)
        {
            stop = threadArgs[i].stop;
        }
    }

    if ((stop-start) > 1000)
    {
        rate = total/((stop-start)/1000);
        
        printf("%d times took %ld milliseconds, performance is %d messages/second\n",
               total, (stop-start), rate);
    }
    else
    {
        printf("interval too short to calculate a message rate\n");
    }

    /* cleanup */
    for (i = 0; i < connections; i++)
    {
        status = tibemsConnection_Close(connArray[i]);
        if (status != TIBEMS_OK)
        {
            fail("Error closing tibemsConnection", status);
        }
    }

    free(connArray);
    free(threadArgs);
    free(threadArray);

    return 0;
}

