/*-#-+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*
*                                                                              *
*       File Name       : tibemsMsgConsumerPerf.c                              *
*                                                                              *
*       Description     : This tool consumes/subscribes messages of a queue/   *
*                         topic respectively                                   *
*                                                                              *
*       EMS Version     : 4.0.0                                                *
*       Supported         4.1.0                                                *
*                         4.2.1 (Not Released)                                 *
*                         4.3.0                                                *
*                         4.4.0 (Not Released)                                 *
*                         4.4.1                                                *
*                         4.4.3                                                *
*                         5.1.4 (Not Released)                                 *
*                         6.0.0 (Not Released)                                 *
*                         6.0.1                                                *
*                         6.1.0                                                *
*                                                                              *
*       Maintenance Log :                                                      *
*                                                                              *
*       Date        Version     Programmer      Description                    *
*       ----------- -------     --------------  ----------------------------   *
*       2008 Jun    1.0         Roshan D'Mello  Creation of original file      *
*                                                                              *
*---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*/


/* 
 * Copyright 2001-2006 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 * 
 * $Id: tibemsMsgConsumerPerf.c 23546 2006-10-27 00:13:21Z $
 * 
 */

/*
 * Usage:  tibemsMsgConsumerPerf [options]
 *
 *  where options are:
 *
 *   -server       <url>         EMS server URL. Default is
 *                               "tcp://localhost:7222".
 *   -user         <username>    User name. Default is null.
 *   -password     <password>    User password. Default is null.
 *   -topic        <topic-name>  Topic name. Default is "topic.sample".
 *   -queue        <queue-name>  Queue name. No default.
 *   -count        <num msgs>    Number of messages to consume. Default is 10k.
 *   -time         <seconds>     Number of seconds to run. Default is 0.
 *   -threads      <num threads> Number of consumer threads. Default is 1.
 *   -connections  <num conns>   Number of consumer connections. Default is 1.
 *   -txnsize      <num msgs>    Number of messages per transaction. Default 0.
 *   -durable      <name>        Durable subscription name.
 *   -selector     <selector>    Message selector for consumer threads. 
 *   -ackmode      <mode>        Message acknowledge mode. Default is AUTO.
 *                               Other values: DUPS_OK, CLIENT EXPLICIT_CLIENT,
 *                               EXPLICIT_CLIENT_DUPS_OK and NO.
 *   -uniquedests                Each consumer thread uses a unique destination.
 */

#include <tibems/tibems.h>
#include <limits.h>
#include <sys/timeb.h>

#include "tibemsUtilities.h"

typedef struct _runArgs
{
    tibemsConnection connection;
    int              number;
    int              count;
    long int         start;
    long int         stop;
} runArgs;

/*-----------------------------------------------------------------------
 * Parameters
 *----------------------------------------------------------------------*/
char*       serverUrl      = "tcp://localhost:7222";
char*       username       = NULL;
char*       password       = NULL;
char*       destination    = "topic.sample";
char*       durable        = NULL;
char*       selector       = NULL;
int         txnSize        = 0;
int         count          = 10000;
int         runTime        = 0;
int         threads        = 1;
int         connections    = 1;
int         ackMode        = TIBEMS_AUTO_ACKNOWLEDGE;
tibems_bool useUniqueDests = TIBEMS_FALSE;
tibems_bool useTopic       = TIBEMS_TRUE;

/*---------------------------------------------------------------------
 * fail
 *---------------------------------------------------------------------*/
void fail(const char* message, tibems_status s)
{
    const char* msg = tibemsStatus_GetText(s);
    printf("ERROR: %s\n", message);
    printf("\tSTATUS: %d %s\n", s, msg ? msg : "(Undefined Error)");
    exit(1);
}

/*-----------------------------------------------------------------------
 * usage
 *----------------------------------------------------------------------*/
void usage() 
{
    printf("\nUsage: tibemsMsgConsumerPerf [options]\n");
    printf("\n");
    printf("   where options are:\n");
    printf("\n");
    printf(" -server       <url>         Server URL. Default is \"tcp://localhost:7222\".\n");
    printf(" -user         <username>    User name. Default is null.\n");
    printf(" -password     <password>    User password. Default is null.\n");
    printf(" -topic        <name>        Topic name. Default is \"topic.sample\".\n");
    printf(" -queue        <name>        Queue name. No default.\n");
    printf(" -durable      <name>        Durable subscription name.\n");
    printf(" -selector     <selector>    Message selector for consumer threads.\n");
    printf(" -ackmode      <mode>        Acknowledge mode: NO, AUTO, DUPS_OK, CLIENT,\n");
    printf("                             EXPLICIT_CLIENT, EXPLICIT_CLIENT_DUPS_OK.\n");
    printf("                             Default is AUTO.\n");
    printf(" -txnsize      <num msgs>    Number of messages per transaction.\n");
    printf(" -count        <num msgs>    Number of messages to receive.\n");
    printf(" -time         <seconds>     Number of seconds to run.\n");
    printf(" -threads      <num threads> Number of consumer threads.\n");
    printf(" -connections  <num conns>   Number of connections.\n");
    printf(" -uniquedests                Each consumer uses a unique destination.\n");
    exit(0);
}

/*-----------------------------------------------------------------------
 * parseArgs
 *----------------------------------------------------------------------*/
void parseArgs(int argc, char** argv) 
{
    int i=1;

    while (i < argc)
    {
        if (!argv[i])
        {
            i += 1;
        }
        else if (strcmp(argv[i],"-help")==0)
        {
            usage();
        }
        else if (strcmp(argv[i],"-server")==0)
        {
            if ((i+1) >= argc) usage();
            serverUrl = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-user")==0)
        {
            if ((i+1) >= argc) usage();
            username = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-password")==0)
        {
            if ((i+1) >= argc) usage();
            password = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-topic")==0)
        {
            if ((i+1) >= argc) usage();
            destination = argv[i+1];
            useTopic = TIBEMS_TRUE;
            i += 2;
        }
        else if (strcmp(argv[i],"-queue")==0)
        {
            if ((i+1) >= argc) usage();
            destination = argv[i+1];
            useTopic = TIBEMS_FALSE;
            i += 2;
        }
        else if (strcmp(argv[i],"-durable")==0)
        {
            if ((i+1) >= argc) usage();
            durable = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-selector")==0)
        {
            if ((i+1) >= argc) usage();
            selector = argv[i+1];
            i += 2;
        }
        else if (strcmp(argv[i],"-ackmode")==0)
        {
            if ((i+1) >= argc) usage();
            if (strcmp(argv[i+1], "NO") == 0)
            {
                ackMode = TIBEMS_NO_ACKNOWLEDGE;
            }
            else if (strcmp(argv[i+1], "AUTO") == 0)
            {
                ackMode = TIBEMS_AUTO_ACKNOWLEDGE;
            }
            else if (strcmp(argv[i+1], "CLIENT") == 0)
            {
                ackMode = TIBEMS_CLIENT_ACKNOWLEDGE;
            }
            else if (strcmp(argv[i+1], "DUPS_OK") == 0)
            {
                ackMode = TIBEMS_DUPS_OK_ACKNOWLEDGE;
            }
            else if (strcmp(argv[i+1], "EXPLICIT_CLIENT") == 0)
            {
                ackMode = TIBEMS_EXPLICIT_CLIENT_ACKNOWLEDGE;
            }
            else if (strcmp(argv[i+1], "EXPLICIT_CLIENT_DUPS_OK") == 0)
            {
                ackMode = TIBEMS_EXPLICIT_CLIENT_DUPS_OK_ACKNOWLEDGE;
            }
            else
            {
                printf("Invalid value for -ackmode: %s\n", argv[i+1]);
                usage();
            }
            i += 2;
        }
        else if (strcmp(argv[i],"-txnsize")==0)
        {
            if ((i+1) >= argc) usage();
            txnSize = atoi(argv[i+1]);
            i += 2;
        }
        else if (strcmp(argv[i],"-count")==0)
        {
            if ((i+1) >= argc) usage();
            count = atoi(argv[i+1]);
            i += 2;
        }
        else if (strcmp(argv[i],"-time")==0)
        {
            if ((i+1) >= argc) usage();
            runTime = atoi(argv[i+1]);
            i += 2;
        }
        else if (strcmp(argv[i],"-threads")==0)
        {
            if ((i+1) >= argc) usage();
            threads = atoi(argv[i+1]);
            if (threads < 1)
            {
                printf("Invalid value for -threads: %s\n", argv[i+1]);
                usage();
            }
            i += 2;
        }
        else if (strcmp(argv[i],"-connections")==0)
        {
            if ((i+1) >= argc) usage();
            connections = atoi(argv[i+1]);
            if (connections < 1)
            {
                printf("Invalid value for -connections: %s\n", argv[i+1]);
                usage();
            }
            i += 2;
        }
        else if (strcmp(argv[i],"-uniquedests")==0)
        {
            useUniqueDests = TIBEMS_TRUE;
            i += 1;
        }
        else
        {
            printf("Unrecognized parameter: %s\n",argv[i]);
            usage();
        }
    }
}

/*---------------------------------------------------------------------
 * acknowledge mode to string
 *---------------------------------------------------------------------*/
char* ackModeToString(int ackmode)
{
    switch (ackmode)
    {
    case TIBEMS_NO_ACKNOWLEDGE:
        return "NO";
    case TIBEMS_AUTO_ACKNOWLEDGE:
        return "AUTO";
    case TIBEMS_CLIENT_ACKNOWLEDGE:
        return "CLIENT";
    case TIBEMS_DUPS_OK_ACKNOWLEDGE:
        return "DUPS_OK";
    case TIBEMS_EXPLICIT_CLIENT_ACKNOWLEDGE:
        return "EXPLICIT_CLIENT";
    case TIBEMS_EXPLICIT_CLIENT_DUPS_OK_ACKNOWLEDGE:
        return "EXPLICIT_CLIENT_DUPS_OK";
    default:
        return "(unknown)";
    }
}

/*---------------------------------------------------------------------
 * current time in milliseconds
 *---------------------------------------------------------------------*/
long int currentMillis()
{
    struct timeb current;
    long int result;

    ftime(&current);
    result = current.time * 1000 + current.millitm;
    return result;
}

/*---------------------------------------------------------------------
 * create destination
 *---------------------------------------------------------------------*/
void createDestination(int num, tibemsDestination* dest)
{
    tibems_status status;
    char*         tmpStr;

    if (useUniqueDests == TIBEMS_TRUE)
    {
        tmpStr = (char*)malloc(strlen(destination)+17);
        sprintf(tmpStr, "%s.%d", destination, num);
    }
    else
    {
        tmpStr = strdup(destination);
    }

    if (useTopic == TIBEMS_TRUE)
    {
        status = tibemsTopic_Create(dest, tmpStr);
    }
    else
    {
        status = tibemsQueue_Create(dest, tmpStr);
    }

    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsDestination", status);
    }

    free(tmpStr);
}

/*---------------------------------------------------------------------
 * run test
 *---------------------------------------------------------------------*/
THREAD_RETVAL run(void* a)
{
    runArgs*          args = (runArgs*) a;
    struct timeb      currentTime, lastTime;
    tibemsDestination dest;
    tibemsSession     session;
    tibemsMsgConsumer consumer;
    tibemsMsg         msg;
    tibems_status     status;
    tibems_long       remaining = 0;
    char*             durableName = NULL;
    int               msgCount = 0;

    tibems_Sleep(250);

    /* create the destination */
    createDestination(args->number, &dest);

    /* create the session */
    status = tibemsConnection_CreateSession(args->connection, 
                                            &session,
                                            txnSize > 0 ? TIBEMS_TRUE : TIBEMS_FALSE,
                                            ackMode);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsSession", status);
    }

    /* create the consumer */
    if (durable != NULL)
    {
        durableName = (char*)malloc(strlen(durable)+17);
        sprintf(durableName, "%s.%d", durable, args->number);
        status = tibemsSession_CreateDurableSubscriber(session,
                                                       &consumer,
                                                       dest,
                                                       durableName,
                                                       selector,
                                                       TIBEMS_FALSE);
    }
    else
    {
        status = tibemsSession_CreateConsumer(session,
                                              &consumer,
                                              dest,
                                              selector,
                                              TIBEMS_FALSE);
    }
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsMsgConsumer", status);
    }

    if (runTime > 0)
    {
        remaining = runTime * 1000;
        ftime(&lastTime);
    }

    /* process messages */
    while (count == 0 || msgCount < (count/threads))
    {
        /* receive next message */
        if (runTime > 0)
        {
            if (remaining <= 0)
            {
                break;
            }
            status = tibemsMsgConsumer_ReceiveTimeout(consumer, &msg, remaining);
            ftime(&currentTime);
            remaining -= ((currentTime.time - lastTime.time)*1000) + 
                         (currentTime.millitm - lastTime.millitm);
            lastTime = currentTime;
        }
        else
        {
            status = tibemsMsgConsumer_Receive(consumer, &msg);
        }

        if (status == TIBEMS_TIMEOUT)
        {
            break;
        }
        else if (status != TIBEMS_OK)
        {
            fail("Error receiving message", status);
        }

        /* start timing */
        if (msgCount == 0)
        {
            args->start = currentMillis();
        }

        msgCount++;

        /* acknowledge message if necessary */
        if (ackMode == TIBEMS_CLIENT_ACKNOWLEDGE ||
            ackMode == TIBEMS_EXPLICIT_CLIENT_ACKNOWLEDGE ||
            ackMode == TIBEMS_EXPLICIT_CLIENT_DUPS_OK_ACKNOWLEDGE)
        {
            status = tibemsMsg_Acknowledge(msg);
            if (status != TIBEMS_OK)
            {
                fail("Error acknowledging message", status);
            }
        }

        /* commit transactions as necessary */
        if (txnSize > 0 && (msgCount % txnSize == 0))
        {
            status = tibemsSession_Commit(session);
            if (status != TIBEMS_OK)
            {
                fail("Error committing transaction", status);
            }
        }

        /* destroy the message */
        status = tibemsMsg_Destroy(msg);
        if (status != TIBEMS_OK)
        {
            fail("Error destroying tibemsMsg", status);
        }
    }

    /* commit any outstanding messages */
    if (txnSize > 0)
    {
        status = tibemsSession_Commit(session);
        if (status != TIBEMS_OK)
        {
            fail("Error committing transaction", status);
        }
    }

    /* stop timing */
    args->stop = currentMillis();
    args->count = msgCount;

    /* close the consumer */
    status = tibemsMsgConsumer_Close(consumer);
    if (status != TIBEMS_OK)
    {
        fail("Error closing tibemsMsgConsumer", status);
    }

    /* unsubscribe durable subscription */
    if (durableName != NULL)
    {
        status = tibemsSession_Unsubscribe(session, durableName);
        if (status != TIBEMS_OK)
        {
            fail("Error unsubscribing", status);
        }

        free(durableName);
    }

    /* destroy destination */
    status = tibemsDestination_Destroy(dest);
    if (status != TIBEMS_OK)
    {
        fail("Error destroying tibemsDestination", status);
    }

    return 0;
}

/*-----------------------------------------------------------------------
 * main
 *----------------------------------------------------------------------*/
int main(int argc, char** argv)
{
    runArgs*          threadArgs;
    THREAD_OBJ*       threadArray;
    tibemsConnection* connArray;
    tibems_status     status = TIBEMS_OK;
    int               i;
    int               total = 0;
    int               rate;
    long int          start = LONG_MAX;
    long int          stop = LONG_MIN;
    tibemsConnectionFactory  factory  = NULL;

    /* parse arguments */
    parseArgs(argc,argv);

    printf("------------------------------------------------------------------------\n");
    printf("tibemsMsgConsumerPerf\n");
    printf("------------------------------------------------------------------------\n");
    printf("Server....................... %s\n", serverUrl != NULL ? serverUrl : "localhost");
    printf("User......................... %s\n", username != NULL ? username : "(NULL)");
    printf("Destination.................. %s\n", destination != NULL ? destination : "(NULL)");
    printf("Consumer Threads............. %d\n", threads);
    printf("Consumer Connections......... %d\n", connections);
    printf("Acknowledge Mode............. %s\n", ackModeToString(ackMode));
    printf("Durable...................... %s\n", durable ? "true" : "false");
    printf("Selector..................... %s\n", selector ? selector : "null");
    if (txnSize > 0)
    {
        printf("Transaction Size............. %d\n", txnSize);
    }
    printf("------------------------------------------------------------------------\n\n");

    factory = tibemsConnectionFactory_Create();
    if (!factory)
    {
        printf("Error creating tibemsConnectionFactory\n");
    }

    status = tibemsConnectionFactory_SetServerURL(factory,serverUrl);
    if (status != TIBEMS_OK) 
    {
        fail("Error setting server url", status);
    }

    /* create the connections */
    connArray = (tibemsConnection*)malloc(sizeof(tibemsConnection)*connections);
    for (i = 0; i < connections; i++)
    {
        status = tibemsConnectionFactory_CreateConnection(factory,&connArray[i],
                                                          username,password);
        if (status != TIBEMS_OK)
        {
            fail("Error creating tibemsConnection", status);
        }

        status = tibemsConnection_Start(connArray[i]);
        if (status != TIBEMS_OK)
        {
            fail("Error starting tibemsConnection", status);
        }
    }

    /* start the threads */
    threadArgs = (runArgs*)malloc(sizeof(runArgs)*threads);
    threadArray = (THREAD_OBJ*)malloc(sizeof(THREAD_OBJ)*threads);
    for (i = 0; i < threads; i++)
    {
        threadArgs[i].connection = connArray[i % connections];
        threadArgs[i].number = i+1;
        THREAD_CREATE(threadArray[i], &run, &threadArgs[i]);
    }

    /* wait for completion */
    ThreadJoin(threads, threadArray);

    /* gather rates */
    for (i = 0; i < threads; i++)
    {
        total += threadArgs[i].count;
        if (threadArgs[i].start < start)
        {
            start = threadArgs[i].start;
        }
        if (threadArgs[i].stop > stop)
        {
            stop = threadArgs[i].stop;
        }
    }

    if ((stop-start) > 1000)
    {
        rate = total/((stop-start)/1000);
        
        printf("%d times took %ld milliseconds, performance is %d messages/second\n",
               total, stop-start, rate);
    }
    else
    {
        printf("interval too short to calculate a message rate\n");
    }

    /* cleanup */
    for (i = 0; i < connections; i++)
    {
        status = tibemsConnection_Close(connArray[i]);
        if (status != TIBEMS_OK)
        {
            fail("Error closing tibemsConnection", status);
        }
    }

    free(connArray);
    free(threadArgs);
    free(threadArray);

    return 0;
}

