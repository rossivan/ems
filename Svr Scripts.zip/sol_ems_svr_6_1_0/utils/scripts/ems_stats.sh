#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : ems_stats.sh                                         #
#                                                                              #
#       Description     : The script collects EMS statistics for a broker      #
#                         instance in a environment for production issue       #
#                         resolution                                           #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2008 Jun    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#

#!/bin/bash

# Obtain the absolute residence directory for this script
curdir=`dirname ${0}`

# Initialize environment variables
. ${curdir}/../../setenv

# Intitialize script variables
brokername=""
environment=""
count=24
interval=5
parse=${SUCCESS}
auth=${FALSE}
protocol=""
os=`uname -s`
cloop=0
admusr=""
admpwd=""
stty_orig=""
args="${*}"

# Parse the input arguments for strict name-value pair combination
while [ ! -z "${1}" -o ! -z "${2}" ]
do
        case "${1}" in
                -brk)
                        shift
                        brokername="${1}"
                        ;;
                -env)
                        shift
                        environment="${1}"
                        ;;
		-cnt)
			shift
			count="${1}"
			;;
		-int)
			shift
			interval="${1}"
			;;
                *)
                        parse=${FAILURE}
                        break
        esac

        shift
done

# Validate the input arguments
if [ ${parse} -ne ${SUCCESS} -o -z "${brokername}" -o -z "${environment}" ]
then
        cat <<USAGE
"${0}" is the EMS statistics collection script. The 'stats.script' can be modified to dictate the desired EMS statistics information collected. Output can be redirected to a file
        -brk(*)		: Unique name of the broker instance in the
                          enterprise
        -env(*)		: Environment for the broker instance. The
                          environment is of the format
                                Development             - dev
                                QualityAssurance        - qa
                                UserAcceptabilityTest   - uat
                                Production              - prod
	-cnt	        : Count of no. of times to collect EMS statistics
                          (24 - default value)
	-int	        : Time interval in secs between consecutive EMS
                          statistics collection
                          (5 secs - default value)

        (*)             : Mandatory arguments
	NOTE		: In addition process specific statistics are also collected
			  Solaris: pmap, pstack, ptree, plimit, pfiles, pflags, pldd
			  ~~~~~~~~ psig, lsof
			  Linux: pmap, pstree, lsof
			  ~~~~~~

USAGE
        exit ${FAILURE}
fi

${EMS_BIN}/auditlog.sh -msg "${0}: ${args}. Collecting EMS statistics for \
broker instance ${brokername} in environment ${environment}..."

# Check for standardized environment names
if [ "${environment}" != "${ENV_DEV}" -a "${environment}" != "${ENV_QA}" -a \
"${environment}" != "${ENV_UAT}" -a "${environment}" != "${ENV_PROD}" ]
then
        ${EMS_BIN}/auditlog.sh -msg "${0}: Incorrect standardized environment \
names. The standardized environment names are 'dev', 'qa', 'uat' and 'prod'..."
        exit ${FAILURE}
fi

# Check for existence of broker instance
if [ ! -d ${EMS_ENVS}/${environment}/${brokername} ]
then
        ${EMS_BIN}/auditlog.sh -msg "${0}: Broker instance \
${brokername} in environment ${environment} does not exist..."
        exit ${FAILURE}
fi

# Generate the tibemsd.properties file
${EMS_BIN}/ems_tibemsdprops.sh -brk ${brokername} -env ${environment}

# Check for failure of generation of the tibemsd.properties file
if [ ${?} == ${FAILURE} ]
then
	${EMS_BIN}/auditlog.sh -msg "${0}: Generation of the tibemsd.properties \
for broker instance ${brokername} in environment ${environment} failed..."
	exit ${FAILURE}
fi

# Initialize broker instance variables
. ${EMS_ENVS}/${environment}/${brokername}/${brokername}.properties
. ${EMS_ENVS}/${environment}/${brokername}/tibemsd.properties

# Check if the EMS product version exists
if [ ! -d ${EMS_INSTALL}/${version} ]
then
        ${EMS_BIN}/auditlog.sh -msg "${0}: Product version \
${EMS_INSTALL}/${version} for broker instance ${brokername} in \
environment ${environment} does not exist..."
        exit ${FAILURE}
fi

# Loop until EMS statistics collection is successful
while [ 1 ]
do
	if [ "${auth}" != "${TRUE}" ]
	then
		echo "" >&2
		echo -n "admin-user: " >&2
		read admusr
		echo -n "admin-password: " >&2
		stty_orig=`stty -g`
		stty -echo
		read admpwd
		stty $stty_orig

		# Start of EMS statistics collection
		echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		echo "##################################################"
		echo "START @ DATE:" `date`
		echo "##################################################"
		echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
	fi

	protocol=`echo ${listen} | cut -f1 -d:`

	if [ "${protocol}" = "${PROTOCOL_TCP}" ]
	then
		# Create user
		${EMS_INSTALL}/${version}/bin/tibemsadmin -server ${listen} \
			-user ${admusr} -password ${admpwd} -script stats.script
	elif [ "${protocol}" = "${PROTOCOL_SSL}" ]
	then
		# Create user
		${EMS_INSTALL}/${version}/bin/tibemsadmin -server ${listen} \
			-user ${admusr} -password ${admpwd} \
			-ssl_trusted `dirname ${ssl_server_trusted}`/${ROOT_TRUSTED_CERT} \
			-ssl_trusted `dirname ${ssl_server_trusted}`/${ISSUER_CERT} \
			-ssl_identity `dirname ${ssl_server_trusted}`/${ADMIN_CERT} \
			-ssl_password ${admpwd} \
			-ssl_hostname ${ft_ssl_expected_hostname} -script stats.script
        else
                ${EMS_BIN}/auditlog.sh -msg "${0}: Unsupported protocol \
'${protocol}' for broker instance ${brokername} in environment ${environment}..."
        fi

	# Check if EMS statistics collection is successful
	if [ ${?} -eq ${SUCCESS} ]
	then
		# Set auth to TRUE if admusr and admpwd result in successful
		# authentication
		auth=${TRUE}

		# Collect process map
		echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		echo "##################################################"
		echo "COLLECT PROCESS MAP"
		echo "##################################################"
		echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
		pmap ${pid}

		# Collect list of open files
		echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		echo "##################################################"
		echo "COLLECT LSOF"
		echo "##################################################"
		echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
		lsof -p ${pid}

		if [ "${os}" = "${LINUX}" ]
		then
			# Collect process tree information
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS TREE INFORMATION"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			pstree ${pid}
		elif [ "${os}" = "${SOLARIS}" ]
		then
			# Collect process stack
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS STACK"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			pstack ${pid}

			# Collect process tree information
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS TREE INFORMATION"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			ptree ${pid}

			# Collect process limit information
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS LIMIT INFORMATION"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			plimit ${pid}

			# Collect process files information
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS FILES INFORMATION"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			pfiles ${pid}

			# Collect process flags information
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS FLAGS INFORMATION"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			pflags ${pid}

			# Collect process dyanmic library information
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS DYNAMIC LIBRARY INFORMATION"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			pldd ${pid}

			# Collect process signal actions information
			echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
			echo "##################################################"
			echo "COLLECT PROCESS SIGNAL ACTIONS INFORMATION"
			echo "##################################################"
			echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
			psig ${pid}
		fi

		# Increase the count of EMS statistics collection
		cloop=`expr ${cloop} + 1`

		# Print separator between consecutive statistics collection
		echo -e "Count: <${cloop}>; Interval: <${interval}> secs" >&2
		echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		echo "##################################################"
		echo "Count: ${cloop} done @ DATE:" `date`
		echo "##################################################"
		echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"

		# Verify if the count of EMS statistics collection can be reduced
		if [ ${cloop} -lt ${count} ]
		then
			# Wait for the specified time interval before collecting EMS
			# statistics
			sleep ${interval}
		else
			break		
		fi
	fi
done

# End of EMS statistics collection
echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo "##################################################"
echo "END @ DATE:" `date`
echo "##################################################"
echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"

${EMS_BIN}/auditlog.sh -msg "${0}: Collected EMS statistics for broker \
instance ${brokername} in environment ${environment}..."

# Successful completion of script
exit ${SUCCESS}


