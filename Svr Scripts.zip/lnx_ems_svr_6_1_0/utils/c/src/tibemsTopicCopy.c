/*-#-+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*
*                                                                              *
*       File Name       : tibemsTopicCopy.c                                    *
*                                                                              *
*       Description     : This tool helps copy messages of a durable topic     *
*                                                                              *
*       EMS Version     : 4.0.0                                                *
*       Supported         4.1.0                                                *
*                         4.2.1 (Not Released)                                 *
*                         4.3.0                                                *
*                         4.4.0 (Not Released)                                 *
*                         4.4.1                                                *
*                         4.4.3                                                *
*                         5.1.4 (Not Released)                                 *
*                         6.0.0 (Not Released)                                 *
*                         6.0.1                                                *
*                         6.1.0                                                *
*                                                                              *
*       Maintenance Log :                                                      *
*                                                                              *
*       Date        Version     Programmer      Description                    *
*       ----------- -------     --------------  ----------------------------   *
*       2008 Jun    1.0         Roshan D'Mello  Creation of original file      *
*                                                                              *
*---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*/


 /* Usage:  tibemsTopicCopy [options]
 *
 *    where options are:
 *
 *      -server     Server URL.
 *                  If not specified this sample assumes a
 *                  serverUrl of "tcp://localhost:7222"
 *
 *      -user       User name. Default is null.
 *      -password   User password. Default is null.
 *      -topic      Topic name. Default is "topic.sample.browser"
 *      -qcopy      Queue to which messages are copied. Default is "queue.sample.copy"
 *      -durable    Durable subscription name
 *      -noofmsg    Number of messages to browse; '0' for all messages [default]
 *      -dispmsg    Display Message. 0 - NO [default] and 1 - YES
 */


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#include <tibems/tibems.h>

/*-----------------------------------------------------------------------
 * Parameters
 *----------------------------------------------------------------------*/

char*   serverUrl    = NULL;
char*   userName     = NULL;
char*   password     = NULL;
char*   pk_password  = NULL;
char*   topicName    = "topic.sample.browser";
char*   qcopyName    = "queue.sample.copy";
char*   durable      = NULL;
int	noofmsg	     = 0;
int	dispmsg	     = 0;


/*-----------------------------------------------------------------------
 * Variables
 *----------------------------------------------------------------------*/
tibemsConnectionFactory       factory          = NULL;
tibemsConnection              connection       = NULL;
tibemsSession                 topicSession     = NULL;
tibemsSession                 queueSession     = NULL;
tibemsMsgConsumer             topicBrowser     = NULL;
tibemsMsgProducer             qcopySender      = NULL;
tibemsDestination             topic            = NULL;           
tibemsDestination             qcopy            = NULL;

/*-----------------------------------------------------------------------
 * usage
 *----------------------------------------------------------------------*/
void usage() 
{
    printf("\nUsage: tibemsTopicCopy [options]\n");
    printf("\n");
    printf("   where options are:\n");
    printf("\n");
    printf(" -server   <server URL>   - EMS server URL, default is local server\n");
    printf(" -user     <user name>    - user name, default is null\n");
    printf(" -password <password>     - password, default is null\n");
    printf(" -topic    <topic-name>   - topic name, default is \"topic.sample.browser\"\n");
    printf(" -qcopy    <qcopy-name>   - Queue to which messages are copied, default is \"queue.sample.copy\"\n");
    printf(" -durable  <durable-name> - durable subscription name\n");
    printf(" -noofmsg  <no. of msg>   - number of messages to browse; '0' for all messages [default]\n");
    printf(" -dispmsg  <display msg>  - Display message payload; 0 - NO [default] and 1 - YES\n"); 
    exit(0);
}

/*-----------------------------------------------------------------------
 * parseArgs
 *----------------------------------------------------------------------*/
void parseArgs(int argc, char** argv) 
{
    int i=1;
    
    while(i < argc)
    {
        if (!argv[i]) 
        {
            i += 1;
        }
        else
        if (strcmp(argv[i],"-help")==0) 
        {
            usage();
        }
        else
        if (strcmp(argv[i],"-server")==0) 
        {
            if ((i+1) >= argc) usage();
            serverUrl = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-topic")==0) 
        {
            if ((i+1) >= argc) usage();
            topicName = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-qcopy")==0)
        {
            if ((i+1) >= argc) usage();
            qcopyName = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-user")==0) 
        {
            if ((i+1) >= argc) usage();
            userName = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-password")==0) 
        {
            if ((i+1) >= argc) usage();
            password = argv[i+1];
            i += 2;
        }
        else
        if (strcmp(argv[i],"-durable")==0)
        {
            if ((i+1) >= argc) usage();
            durable = argv[i+1];
            i += 2;
        }
	else
        if (strcmp(argv[i],"-noofmsg")==0)
        {
            if ((i+1) >= argc) usage();
            noofmsg = atoi(argv[i+1]);
            i += 2;
        }
        else
        if (strcmp(argv[i],"-dispmsg")==0)
        {
            if ((i+1) >= argc) usage();
            dispmsg = atoi(argv[i+1]);
            i += 2;
        }
        else 
        {
            printf("Unrecognized parameter: %s\n",argv[i]);
            usage();
        }
    }

    if(durable == NULL) {
	printf("\n***PROVIDE DURABLE NAME***\n");
	usage();
    }
}

/*---------------------------------------------------------------------
 * fail
 *---------------------------------------------------------------------*/
void fail(
    const char* message, 
    tibems_status s)
{
    const char* msg = tibemsStatus_GetText(s);
    printf("ERROR: %s\n",message);
    printf("\tSTATUS: %d %s\n",s,msg?msg:"(Undefined Error)");
    exit(1);
}

/*---------------------------------------------------------------------
 * onException
 *---------------------------------------------------------------------*/
void onException(
    tibemsConnection    conn,
    tibems_status       reason,
    void*               closure)
{
    /* print the connection exception status */

    if (reason == TIBEMS_SERVER_NOT_CONNECTED)
    {
        printf("CONNECTION EXCEPTION: Server Disconnected\n");
    }
}

/*-----------------------------------------------------------------------
 * closeAll
 *----------------------------------------------------------------------*/
void closeAll() 
{
    tibems_status status   = TIBEMS_OK;

    /* close the browser */
    status = tibemsMsgConsumer_Close(topicBrowser);
    if (status != TIBEMS_OK)
    {
        fail("Error closing tibemsTopicBrowser", status);
    }
    
    /* close the producer */
    status = tibemsMsgProducer_Close(qcopySender);
    if (status != TIBEMS_OK)
    {
        fail("Error closing tibemsMsgProducer", status);
    }

    /* destroy the topic */
    status = tibemsDestination_Destroy(topic);
    if (status != TIBEMS_OK)
    {
        fail("Error destroying tibemsTopic", status);
    }

    /* destroy the queue */
    status = tibemsDestination_Destroy(qcopy);
    if (status != TIBEMS_OK)
    {
        fail("Error destroying tibemsQueue", status);
    }

    /* close the connection */
    status = tibemsConnection_Close(connection);
    if (status != TIBEMS_OK)
    {
        fail("Error closing tibemsConnection", status);
    }
}

/*-----------------------------------------------------------------------
 * run
 *----------------------------------------------------------------------*/
void run() 
{
    tibems_status status   = TIBEMS_OK;
    tibemsMsg     msg      = NULL;
    tibems_int	  msgsize  = 0;
    int           browsec  = 0;
    int           i        = 0;

    if (!topicName) {
        printf("***Error: must specify topic name\n");
        usage();
    }
    
    printf("Browsing topic: '%s'\n",topicName);
    
    factory  = tibemsConnectionFactory_Create();
    if (!factory)
    {
        fail("Error creating tibemsConnectionFactory", status);
    }

    status = tibemsConnectionFactory_SetServerURL(factory,serverUrl);
    if (status != TIBEMS_OK) 
    {
        fail("Error setting server url", status);
    }

    status = tibemsConnectionFactory_CreateConnection(factory,&connection,
                                                           userName,password);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsConnection", status);
    }

    /* set the exception listener */
    status = tibemsConnection_SetExceptionListener(connection,
            onException, NULL);
    if (status != TIBEMS_OK)
    {
        fail("Error setting exception listener", status);
    }

    /* create the topic */
    status = tibemsTopic_Create(&topic,topicName);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsTopic", status);
    }

    /* create the qcopy */
    status = tibemsQueue_Create(&qcopy, qcopyName);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueue", status);
    }

    /* create the topic session -- long running transaction */
    status = tibemsConnection_CreateSession(connection,
            &topicSession,TIBEMS_TRUE,TIBEMS_AUTO_ACKNOWLEDGE);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsSession", status);
    }

    /* create the queue session */
    status = tibemsConnection_CreateSession(connection,
            &queueSession,TIBEMS_FALSE,TIBEMS_AUTO_ACKNOWLEDGE);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsSession", status);
    }
            
    /* start the connection */
    status = tibemsConnection_Start(connection);
    if (status != TIBEMS_OK)
    {
        fail("Error starting tibemsConnection", status);
    }

    /*
     * create browser and browse what is there in the topic
     * create the durable subscriber
     */
    status = tibemsSession_CreateDurableSubscriber(topicSession,
                                                       &topicBrowser,
                                                       topic,
                                                       durable,
						       NULL,
                                                       TIBEMS_FALSE);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsTopicBrowser", status);
    }    

    /* create the queue sender */
    status = tibemsSession_CreateProducer(queueSession,
            &qcopySender, qcopy);
    if (status != TIBEMS_OK)
    {
        fail("Error creating tibemsQueueSender", status);
    }
    
    printf("--- Browsing the topic.\n");
    while(1) 
    {
        /* get the next message */
        status = tibemsMsgConsumer_ReceiveTimeout(topicBrowser,&msg,1000);

        if (status == TIBEMS_TIMEOUT)
	{
    	    printf("--- No more messages in the topic.\n");
            break;
	}

        if (status != TIBEMS_OK)
        {
            fail("Error getting next message from tibemsTopicBrowser", status);
        }

        if(!msg)
            break;

	/* Get messsage size - actual space that the wire format message occupies */
	status = tibemsMsg_GetByteSize(msg, &msgsize);
        if (status != TIBEMS_OK)
        {
            fail("Error getting message byte size", status);
        }

        browsec++;
	
        printf("\n>>> Copied message: number=%d; Message Size: %d bytes <<<\n",browsec, msgsize);
	if(dispmsg != 0) {
		printf(">>> Message Payload <<<\n");
		tibemsMsg_Print(msg);
	}

        /* send the message */
        status = tibemsMsgProducer_Send(qcopySender,msg);
        if (status != TIBEMS_OK)
        {
            fail("Error sending tibemsMsg", status);
        }

        /* destroy the message */
        status = tibemsMsg_Destroy(msg);
        if (status != TIBEMS_OK)
        {
            fail("Error destroying tibemsMsg", status);
        }

	if((noofmsg != 0) && (browsec >= noofmsg))
	    break;
    }
            
    printf("--- Copied specified messages to the queue.\n");
    /*
     * close all and quit
     */
    closeAll();
}
    
/*-----------------------------------------------------------------------
 * main
 *----------------------------------------------------------------------*/
int main(int argc, char** argv)
{
    parseArgs(argc,argv);

    /* print parameters */
    printf("------------------------------------------------------------------------\n");
    printf("tibemsTopicBrowser SAMPLE\n");
    printf("------------------------------------------------------------------------\n");
    printf("Server....................... %s\n",serverUrl?serverUrl:"localhost");
    printf("User......................... %s\n",userName?userName:"(null)");
    printf("Topic........................ %s\n",topicName);
    printf("Durable...................... %s\n",durable);
    printf("QCopy........................ %s\n",qcopyName);
    printf("------------------------------------------------------------------------\n");

    run();

    return 1;
}
