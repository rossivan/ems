/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : Pub.java                                             #
#                                                                              #
#       Description     : The publisher code for the java EMS test harness     #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#       2004 Aug    1.1         Roshan D'Mello  Set the appropriate unique     #
#                                               client-id                      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

// JMS interfaces or "common facilities"
import javax.jms.*;

// JNDI lookup interfaces
import javax.naming.*;

// Standard Java libraries
import java.util.*;

public class Pub implements Runnable {
	private Hashtable env;
	private InitialContext PubInitialContext; // For JNDI lookup
	private long start;
	private long stop;
	private int ThreadId;
	private String destination;
	private int noofdest;
	private int connindex;

	private ConnectionFactory PubConnectionFactory;
	private static Connection PubConnection[];
	private Session PubSession;
	private Destination PubDest[];
	private MessageProducer PubMessageProducer;

	private synchronized int getConnectionIndex(InitialContext PubInitialContext, int ThreadId) {
		if(PubConnection == null) {
			PubConnection = new Connection[Properties.noofconnections];
		}

		connindex =
			((ThreadId % Properties.noofsessions) != 0) ?
			ThreadId / Properties.noofsessions :
			(ThreadId / Properties.noofsessions) - 1;

		if(PubConnection[connindex] == null) {
			try {
				PubConnectionFactory = (ConnectionFactory) PubInitialContext.lookup(Properties.connfact);
				PubConnection[connindex] = PubConnectionFactory.createConnection(Properties.user, Properties.password);
				PubConnection[connindex].setClientID((getClass()).getName() + this.ThreadId + (Properties.type.equals(Constant.TOPIC) ? Properties.topic : Properties.queue) + System.currentTimeMillis());
			} catch(NamingException e) {
				e.printStackTrace();
			} catch(JMSException e) {
				e.printStackTrace();
			}
		}

		return connindex;
	}

	private Pub(int ThreadId) {
		this.ThreadId = ThreadId;

		// Setup the initial context environment for JNDI lookup
		env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, Properties.ProviderContextFactory);
		env.put(Context.PROVIDER_URL, Properties.DefaultProviderURL);	
		env.put(Context.SECURITY_PRINCIPAL, Properties.user);
		env.put(Context.SECURITY_CREDENTIALS, Properties.password);

		try {
			PubInitialContext = new InitialContext(env);	
			connindex = getConnectionIndex(PubInitialContext, ThreadId);
			PubSession = PubConnection[connindex].createSession(Properties.transacted, Properties.ackmode);

                        if(Properties.type.equals(Constant.TOPIC)) {
				noofdest = Properties.nooftopic;
				destination = Properties.topic;
			} else {
				noofdest = Properties.noofqueue;
				destination = Properties.queue;
			}

			PubDest = new Destination[(noofdest <= 1) ? 1 : noofdest];
			for(int iLoop=0; iLoop < ((noofdest <= 1) ? 1 : noofdest); iLoop++) {
				PubDest[iLoop] = (Destination) PubInitialContext.lookup((noofdest==1) ?  (destination+this.ThreadId) : ((noofdest==0) ? destination : (destination+iLoop)));
			}

			noofdest = (noofdest <= 1) ? 1 : noofdest;

			PubMessageProducer = PubSession.createProducer(null);
		} catch(NamingException e) {
			e.printStackTrace();
		} catch(JMSException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		Message PubMessage;
		int 	iLoop, jLoop;

		try {
			PubConnection[connindex].start();

			PubMessage = PubSession.createBytesMessage();

			((BytesMessage) PubMessage).writeBytes(new byte[Properties.messagesize]);

			start = System.currentTimeMillis();

			for(iLoop=0; iLoop < Properties.count;) {
				for(jLoop=0; jLoop < noofdest; jLoop++) {
					PubMessage.setLongProperty(Constant.PUB_TIME, System.currentTimeMillis());
					PubMessage.setStringProperty(Constant.MSG_SEQ_NO, (getClass()).getName() + ThreadId + iLoop); 
					PubMessageProducer.send(PubDest[jLoop], PubMessage, Properties.deliverymode, 0, 0);
					iLoop++;
					if(PubSession.getTransacted() && (iLoop % Properties.batch == 0)) {
						PubSession.commit();
					}
					try {
						if(iLoop % Properties.batch == 0 &&
							Properties.pubrate >= 1000 ) {
							Thread.sleep(Properties.pubrate);
						}
					} catch(InterruptedException ie) {
					}
				}
			}

			// Commit the transacted session for remainder messages
			if(PubSession.getTransacted() && (Properties.count % Properties.batch != 0)) {
				PubSession.commit();
			}

			stop = System.currentTimeMillis();
        		System.out.println((getClass()).getName() +  ThreadId + "[" + (new Date(stop)).toString() + "] -> Messages : " + iLoop + ", Seconds : " + ((double)stop-(double)start)/(double)Constant.SEC + ", Messages/Second : " + ((float)iLoop/(float)(stop-start))*(float)Constant.SEC + "\n");

                        // Close MessageProducer, Session, Connection
                        PubMessageProducer.close();
                        PubSession.close();
		} catch(JMSException e) {
			e.printStackTrace();
                }
	}

	private void displayMessage(Message PubMessage) {
	}

	public static void main(String args[]) {
		int	iLoop;

		Properties.readProperties(args[0]);

		for(iLoop=0; iLoop < Properties.noofpub; iLoop++) {
			Pub p = new Pub(iLoop+1);
			Thread t = new Thread(p);
			if(Properties.count != 0) t.start();
		}
	}
}

