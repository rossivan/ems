#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : dskprf.sh                                            #
#                                                                              #
#       Description     : The script automates the testing of the disk         #
#                         performance in terms of disk writes per second.      #
#                         The utility 'dskprf' is provided by TIBCO.           #
#                         The utility 'dsksynr' is provided by CSFB and        #
#                         confirms the disk performance numbers obtained from  #
#                         the TIBCO utility                                    #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#

#!/bin/bash

# Identify the utility to run (CSFB, TIBCO)
utility=CSFB
# Number of writes to the disk partition
writes=10000
# The disk partition and the file against which the writes need to be executed
file=/e4jms/log.dat
# The write mode to disk and is one of the following (-async, -osync, -fsync)
tiboptions=
csfboptions=-osync

# Delete the log file from previous runs
rm -rf out.dat

if [ "${utility}" = "TIBCO" ]
then
	for size in 1000
	do
		./dskprf -block ${size} -count ${writes} -file ${file} \
			${tiboptions} -prealloc 1>>./out.dat
	done
elif [ "${utility}" = "CSFB" ]
then
	for size in 1000
	do
		./dsksynr -size ${size} -writes ${writes} -file ${file} \
			${csfboptions} 2>>./out.dat
	done
fi
