/*-#-+----1----+----2----+----3----+----4----+----5----+----6----+----7----+---*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*
*                                                                              *
*       File Name       : tibemsUtilities.h                                    *
*                                                                              *
*       Description     : This source file contains shared utility definitions *
*                         for tools                                            *
*                                                                              *
*       EMS Version     : 4.0.0                                                *
*       Supported         4.1.0                                                *
*                         4.2.1 (Not Released)                                 *
*                         4.3.0                                                *
*                         4.4.0 (Not Released)                                 *
*                         4.4.1                                                *
*                         4.4.3                                                *
*                         5.1.4 (Not Released)                                 *
*                         6.0.0 (Not Released)                                 *
*                         6.0.1                                                *
*                         6.1.0                                                *
*                                                                              *
*       Maintenance Log :                                                      *
*                                                                              *
*       Date        Version     Programmer      Description                    *
*       ----------- -------     --------------  ----------------------------   *
*       2008 Jun    1.0         Roshan D'Mello  Creation of original file      *
*                                                                              *
*---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----*
*234567890123456789012345678901234567890123456789012345678901234567890123456789*/


/* 
 * Copyright 2001-2006 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 * 
 * $Id: tibemsUtilities.h 23564 2006-10-28 14:51:47Z $
 * 
 */

#ifndef _INCLUDED_tibemsUtilities_h
#define _INCLUDED_tibemsUtilities_h

#ifdef __MVS__  /* TIBEMSOS_ZOS  */
#include <tibems.h>
#else
#include <tibems/tibems.h>
#endif

#if defined(_WIN32)

#  ifndef _WIN32_WINNT
#    define _WIN32_WINNT 0x0400
#    include <windows.h>
#    include <process.h>
#  endif

#  define THREAD_RETVAL         unsigned __stdcall
#  define THREAD_OBJ            HANDLE
#  define THREAD_CREATE(t,f,a)  t=(HANDLE)_beginthreadex(NULL,0,(f),(a),0,NULL)

#else

#  include <pthread.h>
#  include <errno.h>
#  define THREAD_RETVAL         void*
#  define THREAD_OBJ            pthread_t
#  define THREAD_CREATE(t,f,a)  pthread_create(&(t),NULL,(f),(a))

#endif

extern void
ThreadJoin(
    int              threads,
    THREAD_OBJ*      threadArray);

extern void
sslUsage();

extern void
setSSLParams(
    tibemsSSLParams ssl_params,
    int argc, 
    char* argv[],
    char* *pk_password);

extern void
ldapUsage();

extern tibems_status
setLookupParams(
    tibemsLookupParams lookup_params,
    int argc, 
    char* argv[]);

#endif /* _INCLUDED_tibemsUtilities_h */

