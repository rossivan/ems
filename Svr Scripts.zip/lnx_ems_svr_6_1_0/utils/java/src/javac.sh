#! /bin/ksh

# Set the EMS library version
version=6.1.0

# Obtain the absolute current directory
curdir=`dirname $0`

# Initialize environment variables
. ${curdir}/../../../setenv
. ${curdir}/javaenv

# Compile the applications
$JAVAC -O -deprecation -classpath ${CLASSPATH} -d ${EMS_UTILS}/java $*

