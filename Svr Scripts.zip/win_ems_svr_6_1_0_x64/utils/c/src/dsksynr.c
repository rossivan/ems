/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : dsksynr.c                                            #
#                                                                              #
#       Description     : Tests disk performance as a function of writes/sec   #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#       2004 Aug    2.0         Roshan D'Mello  Modified code to run on Win,   #
#                                               Solaris, Linux                 #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

/* Included Library */
#ifdef WIN32
	#include <io.h> /* write */
	#include <time.h> /* time difftime */
#else
	#include <sys/types.h> /* open */
	#include <sys/stat.h> /* open */
	#include <unistd.h> /* write */
	#include <sys/time.h> /* gettimeofday */
#endif
#include <string.h> /* strcmp strerror */
#include <stdlib.h> /* malloc atoi */
#include <stdio.h> /* fprintf */
#include <fcntl.h> /* open */
#include <errno.h> /* errno */

/* Constants */
#define SIZE "-size" /* Message Size */
#define WRITES "-writes" /* Number of disk writes */
#define FILEP "-filep" /* File path name */
#define ASYNC "-async" /* Asynchronous write (default syncing) */
#define OSYNC "-osync" /* Every write call sync's data */
#define FSYNC "-fsync" /* Execute fsync call after a write call to sync data */
#define S2US 1000000 /* seconds to microseconds */
#define US2S 1E-6 /* microseconds to seconds */

int main(int argc, char *argv[]) {

	/* Declare variables */
	int iLoop; /* Loop variable */
	char *buf; /* Message buffer */
	int size = 0; /* Message size */ 
	int writes = 0; /* Number of disk writes */
	char *filep; /* File path name */
	int async = 0; /* Asynchronous write (default syncing) */
	int osync = 0; /* Every write call sync's data */
	int fsyncs = 0; /* Execute fsync call after a write call to sync data */
	int filedesc; /* File descriptor */
	int oflag; /* Options to open a file */
	double timediff; /* Time difference in seconds */
	double wps; /* Writes per second */
	#ifdef WIN32
		time_t after; /* Sample time before last sync */
		time_t before; /* Sample time after first sync */
	#else
		struct timeval after; /* Sample time before last sync */
		struct timeval before; /* Sample time after first sync */
	#endif

	/* Parse the command line arguments */
	for(iLoop = 0; iLoop < argc; iLoop++) {
		if(!strcmp(SIZE, argv[iLoop])) {
			size = atoi(argv[++iLoop]);
		}
		if(!strcmp(WRITES, argv[iLoop])) {
			writes = atoi(argv[++iLoop]);
		}
		if(!strcmp(FILEP, argv[iLoop])) {
			filep = argv[++iLoop];
		}
		if(!strcmp(ASYNC, argv[iLoop])) {
			async = 1;
		}	
		if(!strcmp(OSYNC, argv[iLoop])) {
			osync = 1;
		}
		if(!strcmp(FSYNC, argv[iLoop])) {
			fsyncs = 1;
		}
	}

	/* Determine the syncing mechanism */
	if(!(osync + fsyncs)) async = 1;

	/* Display usage if parsing fails */
	if(!size || !writes || !filep || ((async + osync + fsyncs) > 1)) {
		fprintf(stderr, "Usage: dsksynr\n\n");
		fprintf(stderr, "-size MessageSize\n");
		fprintf(stderr, "-writes NoOfWrites\n");
		fprintf(stderr, "-filep PathName\n");
		fprintf(stderr, "<-async> [default]\n");
		fprintf(stderr, "<-osync>\n");
		fprintf(stderr, "<-fsync>\n");
		exit(0);
	}

	/* Set the flag options for the data file */
	oflag = O_WRONLY | O_CREAT | O_EXCL;

	/* If O_SYNC has been requested */
	#ifdef WIN32		
	#else
		if(osync) oflag += O_SYNC;
	#endif

	/* Open the data file */
	#ifdef WIN32
		filedesc = _open(filep, oflag);
	#else
		filedesc = open(filep, oflag);
	#endif

	/* Allocate data to be sync'd to disk */
	buf = (char *) malloc(size * sizeof(char));
	memset(buf, 'A', size);

	/* Start instrumenting disk sync rate */
	fprintf(stderr, "Instrumenting Disk Sync Rate...\n");

	/* Sample time before first sync */
	#ifdef WIN32
		time(&before);
	#else
		if(gettimeofday(&before, NULL)) {
			close(filedesc);
			free(buf);
			fprintf(stderr, "Time error: %d\n", errno);
		}
	#endif

	for(iLoop = 0; iLoop < writes; iLoop++) {
		#ifdef WIN32
			if(_write(filedesc, buf, size) != size) {
				close(filedesc);
				free(buf);
				fprintf(stderr, "Write error...\n");
				exit(filedesc);
			}
		#else
			if(write(filedesc, buf, size) != size) {
				close(filedesc);
				free(buf);
				fprintf(stderr, "Write error...\n");
				exit(filedesc);
			}
		#endif

		/* If fsync has been requested */
		#ifdef WIN32
			_commit(filedesc);
		#else
			if(fsyncs) fsync(filedesc);
		#endif
	}

	/* Sample time after last sync */
	#ifdef WIN32
		time(&after);
	#else
		if(gettimeofday(&after, NULL)) {
			close(filedesc);
			free(buf);
			fprintf(stderr, "Time error: %d\n", errno);
		}
	#endif

	#ifdef WIN32
		timediff = (double)difftime(after, before);
		wps = (double)writes/(double)timediff;
	#else
		timediff = (((after.tv_sec*S2US) + after.tv_usec)-((before.tv_sec*S2US) + before.tv_usec)) * US2S;
		wps = (double)writes/(double)timediff;
	#endif

	/* Close the data file */
	#ifdef WIN32
		_close(filedesc);
	#else
		close(filedesc);
	#endif

    /* Free allocated data */
    free(buf);                                                              

	/* Delete the file */
	#ifdef WIN32
		if(remove(filep) == -1) {
			fprintf(stderr, "Cannot delete file, ERROR: %s\n", strerror(errno));
		}
	#else
		if(unlink(filep) == -1) {
			fprintf(stderr, "Cannot delete file, ERROR: %s\n", strerror(errno));
		}
	#endif

	/* Calculate disk sync rate */
	fprintf(stderr, "Message Size : %d\n", size);
	fprintf(stderr, "No. Of Writes : %d\n", writes);
	fprintf(stderr, "Time Difference : %f\n", timediff);
	fprintf(stderr, "Disk Sync Rate : %f\n", wps);

	exit(0);
}

