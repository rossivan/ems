#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : jms_properties.sh                                    #
#                                                                              #
#       Description     : The script generates broker instance JMS properties  #
#                         for Java JMS tests                                   #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#       2004 Aug    1.1         Roshan D'Mello  Arguments adhere to standards  #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#

#! /bin/bash

# Obtain the absolute current directory
curdir=`dirname $0`

# Initialize environment variables
. ${curdir}/../../../setenv

# Intitialize script variables
brokername=""
protocol="tcp"
hostname=""
port=""
parse=${SUCCESS}
brkrpropabspath=""

# Initialize JMS test harness properties
# Test Type
test=performance
# JMS parameters
no_of_connections=1
no_of_sessions=1
transacted=false
message_size=1024
count=100000
time=300
batch=1
mode=count
# Destination information
type=topic
topic=ROSST
no_of_topic=1
queue=ROSSQ
no_of_queue=1
# Publisher information
no_of_pub=1
delivery_mode=nonpersistent
dup_message=true
pub_rate=0
# Subscriber information
no_of_sub=1
ack_mode=autoack
durable=false
sub_rate=0

# Parse the input arguments for strict name-value pair combination
while [ ! -z "${1}" -o ! -z "${2}" ]
do
        case ${1} in
                -brk)
                        shift
                        brokername=${1}
                        ;;
                -protocol)
                        shift
                        protocol=${1}
                        ;;
		-host)
			shift
			hostname=${1}
			;;
                -port)
                        shift
                        port=${1}
                        ;;
                -test)
                        shift
                        test="$1"
                        ;;
		-no_of_connections)
			shift
			no_of_connections="$1"
			;;
		-no_of_sessions)
			shift
			no_of_sessions="$1"
			;;
                -monitor_topic)
                        shift
                        monitor_topic="$1"
                        ;;
                -no_of_mthread)
                        shift
                        no_of_mthread="$1"
                        ;;
                -transacted)
                        shift
                        transacted="$1"
                        ;;
                -message_size)
                        shift
                        message_size="$1"
                        ;;
                -count)
                        shift
                        count="$1"
                        ;;
                -time)
                        shift
                        time="$1"
                        ;;
                -batch)
                        shift
                        batch="$1"
                        ;;
                -mode)
                        shift
                        mode="$1"
                        ;;
                -type)
                        shift
                        type="$1"
                        ;;
                -topic)
                        shift
                        topic="$1"
                        ;;
                -no_of_topic)
                        shift
                        no_of_topic="$1"
                        ;;
                -queue)
                        shift
                        queue="$1"
                        ;;
                -no_of_queue)
                        shift
                        no_of_queue="$1"
                        ;;
                -no_of_pub)
                        shift
                        no_of_pub="$1"
                        ;;
                -delivery_mode)
                        shift
                        delivery_mode="$1"
                        ;;
                -dup_message)
                        shift
                        dup_message="$1"
                        ;;
		-pub_rate)
			shift
			pub_rate="$1"
			;;
                -no_of_sub)
                        shift
                        no_of_sub="$1"
                        ;;
		-ack_mode)
			shift
			ack_mode="$1"
			;;
                -durable)
                        shift
                        durable="$1"
                        ;;
		-sub_rate)
			shift
			sub_rate="$1"
			;;
                *)
                        parse=${FAILURE}
                        break
        esac

        shift
done

# Validate the input arguments
if [ ${parse} -ne ${SUCCESS} -o -z "${brokername}" -o -z "${hostname}" -o \
-z "${port}" ]
then
        cat <<USAGE
${0} is the broker instance JMS properties generation script for JAVA JMS tests
        -brk(*)		: Unique name of the primary broker instance in the
                          enterprise
        -protocol       : Communication protocol for the primary broker instance
                          (tcp - default value)
        -host(*)    	: Communication hostname/IP address for the primary
                          broker instance
        -port(*)        : Communication port for the primary broker instance
USAGE
        exit ${FAILURE}
fi

brkrpropabspath=${EMS_UTILS}/java/${brokername}.properties

touch ${brkrpropabspath}
echo "# Broker ${brokername} information" > ${brkrpropabspath}
echo "brokername=${brokername}" >> ${brkrpropabspath}
echo "user=emstest" >> ${brkrpropabspath}
echo "password=emstest" >> ${brkrpropabspath}
echo "url=${protocol}://${hostname}:${port}" >> ${brkrpropabspath}
echo provider_context_factory=com.tibco.tibjms.naming.TibjmsInitialContextFactory >> ${brkrpropabspath}
echo default_provider_url=tibjmsnaming://${hostname}:${port} >> ${brkrpropabspath}
echo connection_factory=ConnectionFactory >> ${brkrpropabspath}
echo monitor_topic=${monitor_topic} >> ${brkrpropabspath}
echo no_of_mthread=1 >> ${brkrpropabspath}
echo '# Test Type' >> ${brkrpropabspath}
echo test=${test} >> ${brkrpropabspath}
echo '# JMS parameters' >> ${brkrpropabspath}
echo no_of_connections=${no_of_connections} >> ${brkrpropabspath}
echo no_of_sessions=${no_of_sessions} >> ${brkrpropabspath}
echo transacted=${transacted} >> ${brkrpropabspath}
echo message_size=${message_size} >> ${brkrpropabspath}
echo count=${count} >> ${brkrpropabspath}
echo time=${time} >> ${brkrpropabspath}
echo batch=${batch} >> ${brkrpropabspath}
echo mode=${mode} >> ${brkrpropabspath}
echo '# Destination information' >> ${brkrpropabspath}
echo type=${type} >> ${brkrpropabspath}
echo topic=${topic} >> ${brkrpropabspath}
echo no_of_topic=${no_of_topic} >> ${brkrpropabspath}
echo queue=${queue} >> ${brkrpropabspath}
echo no_of_queue=${no_of_queue} >> ${brkrpropabspath}
echo '# Publisher information' >> ${brkrpropabspath}
echo no_of_pub=${no_of_pub} >> ${brkrpropabspath}
echo delivery_mode=${delivery_mode} >> ${brkrpropabspath}
echo dup_message=${dup_message} >> ${brkrpropabspath}
echo pub_rate=${pub_rate} >> ${brkrpropabspath}
echo '# Subscriber information' >> ${brkrpropabspath}
echo no_of_sub=${no_of_sub} >> ${brkrpropabspath}
echo ack_mode=${ack_mode} >> ${brkrpropabspath}
echo durable=${durable} >> ${brkrpropabspath}
echo sub_rate=${sub_rate} >> ${brkrpropabspath}

