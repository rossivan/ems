/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : httpreqres.h                                         #
#                                                                              #
#       Description     : This header file contains constants                  #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2005 Sep    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

#ifndef HTTPREQRES_H_
#define HTTPREQRES_H_

/* Success / Failure */
#define SUCCESS 0
#define FAILURE 1

/* HTTP Information */
#define HTTP_PORT       80 /* HTTP port */
#define HTTP_BUFF_SIZE  10000 /* HTTP request-response buffer */
#define WS_RETRY		3 /* Web Services Retry Count */
#define WS_TIMEOUT		10 /* Web Services Time Out */
#define WS_SUCCESS		"sql_code=0" /* Web Services Success */

#endif

