#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : ems_stats.pl                                         #
#                                                                              #
#       Description     : The script collects EMS statistics for a broker      #
#                         instance in a environment for production issue       #
#                         resolution                                           #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2008 Jun    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#

#!perl -w

# Include the packages required by this script
use File::Basename; # Portably parse a pathname into directory, basename, and
					# extension components
use File::Spec::Functions; # Use portable filename operations (functional)
						   # interface
use Getopt::Long; # Process extended command-line options in long form (-xxx)
use Term::ReadKey; # Simple terminal control
use lib "../../bin"; # Required to find the 'shared' module below
use shared; # EMS Shared package contains common functions
use strict; # Stricture makes perl treat all barewords as syntax errors

# Initialize environment variables
initenv(catfile(dirname($0), "../../", "setenv"));

# Intitialize script variables
my $brokername="";
my $environment="";
my $count=24;
my $interval=5;
my $parse=$ENV{"SUCCESS"};
my $auth=$ENV{"FALSE"};
my $protocol="";
my $cloop=0;
my $admusr="";
my $admpwd="";
my @args=@ARGV;

# Parse the input arguments for strict name-value pair combination
if( !GetOptions('brk=s'		=> \$brokername,
				'env=s'		=> \$environment,
				'cnt:s'		=> \$count,
				'int:s'		=> \$interval) ) {
	Usage();
	exit($ENV{"FAILURE"});
}

# Validate the input arguments
if( length($brokername) == 0 || length($environment) == 0 ) {
	Usage();
	exit($ENV{"FAILURE"});
}

auditlog("${0}: @args. Collecting EMS statistics for " .
"broker instance ${brokername} in environment ${environment}...\n");

# Check for standardized environment names
if( ${environment} ne $ENV{"ENV_DEV"} && ${environment} ne $ENV{"ENV_QA"} &&
${environment} ne $ENV{"ENV_UAT"} && ${environment} ne $ENV{"ENV_PROD"} ) {
        auditlog("${0}: Incorrect standardized environment " .
"names. The standardized environment names are 'dev', 'qa', 'uat' and 'prod'...\n");
        exit($ENV{"FAILURE"});
}

# Check for existence of broker instance
if( ! -d catfile($ENV{"EMS_ENVS"}, $environment, $brokername)) {
	auditlog("${0}: Broker instance " .
"${brokername} in environment ${environment} does not exist...\n");
    exit($ENV{"FAILURE"});
}

# Initialize broker instance variables
initenv(catfile($ENV{"EMS_ENVS"}, $environment, $brokername, "${brokername}.properties"));
initenv(catfile($ENV{"EMS_ENVS"}, $environment, $brokername, "config", "tibemsd.conf"));

# Check if the EMS product version exists
if( ! -d catfile($ENV{"EMS_INSTALL"}, $ENV{"version"})) {
    auditlog("${0}: Product version " .
catfile($ENV{"EMS_INSTALL"}, $ENV{"version"}) . " for broker instance ${brokername} in " .
"environment ${environment} does not exist...\n");
    exit($ENV{"FAILURE"});
}

# Loop until EMS statistics collection is successful
while( 1 ) {
	if( $auth ne $ENV{"TRUE"} ) {
		print STDOUT "\n";
		print STDOUT "admin-user: ";
		ReadMode 'normal';
		$admusr=ReadLine 0;
		chomp($admusr);
		print STDOUT "admin-password: ";
		ReadMode 'noecho';
		$admpwd=ReadLine 0;
		chomp($admpwd);
		ReadMode 'normal';

		# Start of EMS statistics collection
		print STDERR "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
		print STDERR "\n##################################################";
		print STDERR "\nSTART @ DATE:" . localtime;
		print STDERR "\n##################################################";
		print STDERR "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
	}

	$protocol=substr($ENV{"listen"}, 0, 3);

	if( $protocol eq $ENV{"PROTOCOL_TCP"} ) {
		# Create user
		@args = (catfile($ENV{"EMS_INSTALL"}, $ENV{"version"}, "bin", "tibemsadmin"),
			"-server", $ENV{"listen"},
			"-user", "$admusr",
			"-password", "$admpwd",
			"-script", "stats.script");
	} elsif( $protocol eq $ENV{"PROTOCOL_SSL"} ) {
		# Create user
		@args = (catfile($ENV{"EMS_INSTALL"}, $ENV{"version"}, "bin", "tibemsadmin"),
			"-server", $ENV{"listen"},
			"-user", "$admusr",
			"-password", "$admpwd",
			"-ssl_trusted", catfile(dirname($ENV{"ssl_server_trusted"}), $ENV{"ROOT_TRUSTED_CERT"}),
			"-ssl_trusted", catfile(dirname($ENV{"ssl_server_trusted"}), $ENV{"ISSUER_CERT"}),
			"-ssl_identity", catfile(dirname($ENV{"ssl_server_trusted"}), $ENV{"ADMIN_CERT"}),
			"-ssl_password", "$admpwd",
			"-ssl_hostname", $ENV{"ft_ssl_expected_hostname"},
			"-script", "stats.script");
	} else {
		auditlog("${0}: Unsupported protocol '${protocol}' for broker instance " .
"${brokername} in environment ${environment}...\n");
			exit($ENV{"FAILURE"});
	}

	# Check if EMS statistics collection is successful
	if( system(@args) eq $ENV{"SUCCESS"} ) {
		# Set auth to TRUE if admusr and admpwd result in successful
		# authentication
		$auth=$ENV{"TRUE"};
		
		# Increase the count of EMS statistics collection
		$cloop = $cloop + 1;
		
		# Print separator between consecutive statistics collection
		print STDERR "\nCount: <${cloop}>; Interval: <${interval}> secs";
		print STDERR "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
		print STDERR "\n##################################################";
		print STDERR "\nCount: ${cloop} done @ DATE:" . localtime;
		print STDERR "\n##################################################";
		print STDERR "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
		
		# Verify if the count of EMS statistics collection can be reduced
		if( $cloop < $count ) {
			# Wait for the specified time interval before collecting EMS
			# statistics
			sleep ${interval};
		} else {
			last;
		}
	} 
}

# End of EMS statistics collection
print STDERR "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";
print STDERR "\n##################################################";
print STDERR "\nEND @ DATE:" . localtime;
print STDERR "\n##################################################";
print STDERR "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!";

auditlog("${0}: @args. Collected EMS statistics for " .
"broker instance ${brokername} in environment ${environment}...\n");

# Successful completion of script
exit($ENV{"SUCCESS"});

# Explains the usage of this module
sub Usage() {
print <<"USAGE";
"${0}" is the EMS statistics collection script. The 'stats.script' can be modified to dictate the desired EMS statistics information collected. Output can be redirected to a file.
    -brk(*)     : Unique name of the broker instance in the
                  enterprise
    -env(*)     : Environment for the broker instance. The
                  environment is of the format
                        Development             - dev
                        QualityAssurance        - qa
                        UserAcceptabilityTest   - uat
                        Production              - prod
    -cnt        : Count of no. of times to collect EMS statistics
                  (24 - default value)
    -int        : Time interval in secs between consecutive EMS
                  statistics collection
                  (5 secs - default value)

    (*)         : Mandatory arguments
USAGE
}

1;
__END__