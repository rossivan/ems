/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : SubPub.java                                          #
#                                                                              #
#       Description     : The subscriber-publisher code for the java EMS       #
#                         test harness                                         #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #      
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#       2004 Aug    1.1         Roshan D'Mello  Set the appropriate unique     #
#                                               client-id                      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

// JMS interfaces or "common facilities"
import javax.jms.*;

// JNDI lookup interfaces
import javax.naming.*;

// Standard Java libraries
import java.util.*;

public class SubPub implements Runnable {
        private Hashtable env;
        private InitialContext SubPubInitialContext; // For JNDI lookup
        private long start;
        private long stop;
	private long tstart; // Transaction start
	private long tstop; // Transaction stop
	private long tmin=Constant.TIME_MAX; // Transaction minimum
	private long tmax=Constant.TIME_MIN; // Transaction maximum
	private long tavg=0; // Transaction average
	private long tdiff;
	private long lmin=Constant.TIME_MAX; // Latency minimum
	private long lmax=Constant.TIME_MIN; // Latency maximum
	private long lavg=0; // Latency average
	private long ldiff;
        private int ThreadId;
	private String destination;
        private int noofdest;

	private ConnectionFactory SubPubConnectionFactory;
	private Connection SubPubConnection;
	private Session SubPubSession;
	private MessageConsumer SubPubMessageConsumer;
	private MessageProducer SubPubMessageProducer;
	private Destination SubPubDest[];
	
	private SubPub(int ThreadId) {
		this.ThreadId = ThreadId;

		env = new Hashtable();
		env.put(Context.INITIAL_CONTEXT_FACTORY, Properties.ProviderContextFactory);
		env.put(Context.PROVIDER_URL, Properties.DefaultProviderURL);
		env.put(Context.SECURITY_PRINCIPAL, Properties.user);
                env.put(Context.SECURITY_CREDENTIALS, Properties.password);

		try {
			SubPubInitialContext = new InitialContext(env);
			SubPubConnectionFactory = (ConnectionFactory) SubPubInitialContext.lookup(Properties.connfact);
			SubPubConnection = SubPubConnectionFactory.createConnection(Properties.user, Properties.password);
			SubPubConnection.setClientID((getClass()).getName() + this.ThreadId + (Properties.type.equals(Constant.TOPIC) ? Properties.topic : Properties.queue));
			SubPubSession = SubPubConnection.createSession(Properties.transacted, Properties.ackmode);

			if(Properties.type.equals(Constant.TOPIC)) {
                                noofdest = Properties.nooftopic;
                                destination = Properties.topic;
                        } else {
                                noofdest = Properties.noofqueue;
                                destination = Properties.queue;
                        }

			SubPubMessageConsumer = SubPubSession.createConsumer((Destination) SubPubInitialContext.lookup(destination));

			SubPubDest = new Destination[noofdest];
			for(int iLoop=0; iLoop < noofdest;) {
				SubPubDest[iLoop] = (Destination) SubPubInitialContext.lookup(destination+(++iLoop));
                        }

			SubPubMessageProducer = SubPubSession.createProducer(null);	
		} catch(NamingException e) {
			e.printStackTrace();
		} catch(JMSException e) {
			e.printStackTrace();
		}
	}

	public void run() {
                Message SubPubMessage;
		int	iLoop, jLoop;

                try {
                        SubPubConnection.start();


                        for(iLoop=0,jLoop=0; iLoop < Properties.count;) {
				SubPubMessage = SubPubMessageConsumer.receive();

				lavg += ldiff = (System.currentTimeMillis() - SubPubMessage.getLongProperty(Constant.PUB_TIME));
				SubPubMessage.getStringProperty(Constant.MSG_SEQ_NO);
				if(ldiff < lmin) {
					lmin = ldiff;
				} else if(ldiff > lmax) {
					lmax = ldiff;
				}

				if(iLoop == 0) {
                        		start = System.currentTimeMillis();
					tstart = System.currentTimeMillis();
				}

				if(SubPubMessage == null) {
                                        break;
                                }

				displayMessage(SubPubMessage);

				for(;jLoop < noofdest;) {
                                	SubPubMessageProducer.send(SubPubDest[jLoop], SubPubMessage, Properties.deliverymode, 0, 0);
					jLoop++;
					if(!Properties.dupmessage) {
						break;
					}
				}

				iLoop++;
                                if(SubPubSession.getTransacted() && (iLoop % Properties.batch == 0)) {
					SubPubSession.commit();
					tstop = System.currentTimeMillis();

					// Calculate min, max, average transaction time
					tavg += tdiff = (tstop-tstart);
					if(tdiff < tmin) {
						tmin = tdiff;
					} else if(tdiff > tmax) {
						tmax = tdiff;
					}
					tstart = System.currentTimeMillis();
				}

				jLoop = (jLoop < noofdest) ? jLoop : 0;
                        }

                        // Commit the transacted session for remainder messages
                        if(SubPubSession.getTransacted() && (Properties.count % Properties.batch != 0)) {
                                SubPubSession.commit();
                                tstop = System.currentTimeMillis();

                                // Calculate min, max, average transaction time
                                tavg += tdiff = (tstop-tstart);
                                if(tdiff < tmin) {
                                        tmin = tdiff;
                                } else if(tdiff > tmax) {
                               		tmax = tdiff;
                        	}
                        }

                        stop = System.currentTimeMillis();
                        System.out.println((getClass()).getName() +  ThreadId + "[" + (new Date(stop)).toString() + "] -> Messages : " + iLoop + ", Seconds : " + ((double)stop-(double)start)/(double)1000 + ", Messages/Second : " + ((float)iLoop/(float)(stop-start))*(float)1000 + ", XTime (ms): " + (float)tavg/((float)iLoop/(float)Properties.batch) + " (Avg), " + tmin + " (Min), " + tmax + " (Max)" + ", Latency (ms) : " + (float)lavg/(float)iLoop + " (Avg), " + lmin + " (Min), " + lmax + " (Max)\n");

                        // Close MessageProducer, Session, Connection
                        SubPubMessageProducer.close();
                        SubPubSession.close();
                        SubPubConnection.close();
                } catch(JMSException e) {
                        e.printStackTrace();
                }
	}

        private void displayMessage(Message PubMessage) {
        }

	public static void main(String args[]) {
		int     iLoop;

                Properties.readProperties(args[0]);

		for(iLoop=0; iLoop < Properties.noofsub; iLoop++) {
			SubPub sp = new SubPub(iLoop+1);
			Thread t = new Thread(sp);
			if(Properties.count != 0) t.start();
		}
	}
}

