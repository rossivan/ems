#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : ems_stats.sh                                         #
#                                                                              #
#       Description     : The script gets core image of running EMS broker     #
#                         process                                              #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2008 Jun    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#

#!/bin/bash

# Obtain the absolute residence directory for this script
curdir=`dirname ${0}`

# Initialize environment variables
. ${curdir}/../../setenv

# Intitialize script variables
brokername=""
environment=""
parse=${SUCCESS}
args="${*}"

# Parse the input arguments for strict name-value pair combination
while [ ! -z "${1}" -o ! -z "${2}" ]
do
        case "${1}" in
                -brk)
                        shift
                        brokername="${1}"
                        ;;
                -env)
                        shift
                        environment="${1}"
                        ;;
                *)
                        parse=${FAILURE}
                        break
        esac

        shift
done

# Validate the input arguments
if [ ${parse} -ne ${SUCCESS} -o -z "${brokername}" -o -z "${environment}" ]
then
        cat <<USAGE
"${0}" is the runtime core image generation script
        -brk(*)		: Unique name of the broker instance in the
                          enterprise
        -env(*)		: Environment for the broker instance. The
                          environment is of the format
                                Development             - dev
                                QualityAssurance        - qa
                                UserAcceptabilityTest   - uat
                                Production              - prod

        (*)             : Mandatory arguments
	NOTE		: The script generates a gcorefile.<pid> file
USAGE
        exit ${FAILURE}
fi

${EMS_BIN}/auditlog.sh -msg "${0}: ${args}. Generating runtime core image \
for broker instance ${brokername} in environment ${environment}..."

# Check for standardized environment names
if [ "${environment}" != "${ENV_DEV}" -a "${environment}" != "${ENV_QA}" -a \
"${environment}" != "${ENV_UAT}" -a "${environment}" != "${ENV_PROD}" ]
then
        ${EMS_BIN}/auditlog.sh -msg "${0}: Incorrect standardized environment \
names. The standardized environment names are 'dev', 'qa', 'uat' and 'prod'..."
        exit ${FAILURE}
fi

# Check for existence of broker instance
if [ ! -d ${EMS_ENVS}/${environment}/${brokername} ]
then
        ${EMS_BIN}/auditlog.sh -msg "${0}: Broker instance \
${brokername} in environment ${environment} does not exist..."
        exit ${FAILURE}
fi

# Generate the tibemsd.properties file
${EMS_BIN}/ems_tibemsdprops.sh -brk ${brokername} -env ${environment}

# Check for failure of generation of the tibemsd.properties file
if [ ${?} == ${FAILURE} ]
then
	${EMS_BIN}/auditlog.sh -msg "${0}: Generation of the tibemsd.properties \
for broker instance ${brokername} in environment ${environment} failed..."
	exit ${FAILURE}
fi

# Initialize broker instance variables
. ${EMS_ENVS}/${environment}/${brokername}/${brokername}.properties
. ${EMS_ENVS}/${environment}/${brokername}/tibemsd.properties

# Check if the EMS product version exists
if [ ! -d ${EMS_INSTALL}/${version} ]
then
        ${EMS_BIN}/auditlog.sh -msg "${0}: Product version \
${EMS_INSTALL}/${version} for broker instance ${brokername} in \
environment ${environment} does not exist..."
        exit ${FAILURE}
fi

# Generating runtime core image
echo -e "\n!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
echo "##################################################"
echo "GENERATING RUNTIME CORE IMAGE"
echo "##################################################"
echo -e "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n"
gcore -o gcorefile ${pid}

${EMS_BIN}/auditlog.sh -msg "${0}: Generated runtime core image \
for broker instance ${brokername} in environment ${environment}..."

# Successful completion of script
exit ${SUCCESS}

