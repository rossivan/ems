#! /bin/ksh

version=6.1.0

# Obtain the absolute current directory
curdir=`dirname $0`

# Initialize environment variables
. ${curdir}/../../../setenv
. ${curdir}/javaenv

# Execute the application
${JAVAE} ${JVM_OPTION} -classpath ${CLASSPATH} $*

