/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#234567890123456789012345678901234567890123456789012345678901234567890123456789#
#                                                                              #
#       File Name       : Constant.java                                        #
#                                                                              #
#       Description     : Defines constants required by the java EMS test      #
#                         harness                                              #
#                                                                              #
#       EMS Version     : 4.0.0                                                #
#       Supported         4.1.0                                                #
#                         4.2.1 (Not Released)                                 #
#                         4.3.0                                                #
#                         4.4.0 (Not Released)                                 #
#                         4.4.1                                                #
#                         4.4.3                                                #
#                         5.1.4 (Not Released)                                 #
#                         6.0.0 (Not Released)                                 #
#                         6.0.1                                                #
#                         6.1.0                                                #
#                                                                              #
#       Maintenance Log :                                                      #
#                                                                              #
#       Date        Version     Programmer      Description                    #
#       ----------- -------     --------------  ----------------------------   #
#       2004 May    1.0         Roshan D'Mello  Creation of original file      #
#                                                                              #
#---+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----#
#23456789012345678901234567890123456789012345678901234567890123456789012345678*/

public class Constant {
	// Broker and connection information
	public static final String BROKERNAME = "brokername";
	public static final String URL = "url";
	public static final String USER = "user";
	public static final String PASSWORD = "password";
	public static final String PROVIDER_CONTEXT_FACTORY = "provider_context_factory";
	public static final String DEFAULT_PROVIDER_URL = "default_provider_url";
	public static final String CONNECTION_FACTORY = "connection_factory";

	// Test Type
	public static final String TEST = "test";
	public static final String TEST_PERFORMANCE = "performance";
	public static final String TEST_RECOVERY = "recovery";

	// Monitoring information
	public static final String MONITOR_TOPIC = "monitor_topic";
        public static final String NO_OF_MTHREAD = "no_of_mthread";

	// JMS parameters
	public static final String NO_OF_CONNECTIONS = "no_of_connections";
	public static final String NO_OF_SESSIONS = "no_of_sessions";
	public static final String TRANSACTED = "transacted";
        public static final String MESSAGE_SIZE = "message_size";
        public static final String COUNT = "count";
	public static final String TIME = "time";
	public static final String BATCH = "batch";
	public static final String MODE = "mode";
	public static final String MODE_COUNT = "count";
	public static final String MODE_TIME = "time";
	public static final String PERSISTENT = "persistent";
	public static final String NONPERSISTENT = "nonpersistent";
	public static final String RELIABLE = "reliable";
	public static final String AUTOACK = "autoack";
	public static final String DUPSOK = "dupsok";
	public static final String NOACK = "noack";

	// Destination information
	public static final String TYPE = "type";
	public static final String UNIVERSAL_TOPIC = ">";
	public static final String DUMMY_TOPIC = "dummy";
	public static final String TOPIC = "topic";
	public static final String NO_OF_TOPIC = "no_of_topic";
	public static final String QUEUE = "queue";
	public static final String NO_OF_QUEUE = "no_of_queue";

	// Publisher information
	public static final String NO_OF_PUB = "no_of_pub";
	public static final String DELIVERY_MODE = "delivery_mode";
	public static final String DUP_MESSAGE = "dup_message";
	public static final String PUB_RATE = "pub_rate";

	// Consumer information
	public static final String NO_OF_SUB = "no_of_sub";
	public static final String ACK_MODE = "ack_mode";
	public static final String DURABLE = "durable";
	public static final String SUB_RATE="sub_rate";

	// Milli-second durations
	public static final long SEC = 1000;
	public static final long MIN = 60 * SEC;
	public static final long HOUR = 60 * MIN;
	public static final long DAY = 24 * HOUR;
	public static final long TIME_MAX = DAY;
	public static final long TIME_MIN = -DAY;

	// Message properties
	public static final String PUB_TIME = "PubTime";
	public static final String MSG_SEQ_NO = "MsgSeqNo";
	public static final String SUBPUB_TIME = "SubPubTime";
}

